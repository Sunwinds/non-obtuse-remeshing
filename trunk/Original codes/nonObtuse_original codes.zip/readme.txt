To compile:
- use Makefile to compile under 64bit machines
- use Makefile_32bit to compile under 32bit machines
glui static libraries are placed under spectre/Temp/nonobtuse_lib, so if you move those files you'll need to modify the makefile
if there's linking problem, then you may need to add the nonobtuse_lib path to your LD_LIBRARY_PATH environment variable (ex. setenv LD_LIBRARY_PATH ${LD_LIBRARY_PATH}:/gruvi/Data/Projects/SpectrE/Temp/nonobtuse_lib/lib)

Files
- main.cpp
    - entry pointm, GUI, globals
- smfparser.h, smfparser.cpp
    - SMF parser class
- CIsoSurface.h, CIsoSurface.cpp
    - Original Marching Cubes code downloaded off the web
- cnonobtusemc.h, cnonobtusemc.cpp
    - subclass of CIsoSurface, modifications to acheive nonobtusity
- tilingnonobtusemc.h, tilingnonobtusemc.cpp
    - subclass of CNonobtuseMC, modifications to achieve nonobtuse marching cubes without scalarfield
- nonobtuse.h, nonobtuse.cpp
    - helpers specific for nonobtuse meshing + scalarfield generation
- renderer.h, renderer.cpp
    - renders mesh
- helper.h, helper.cpp
    - generic helpers
- nonobtoptn.h, nonobtoptn.cpp
    - nonobtuse optimization including decimation
- Vectors.h, Vectors.cpp
    - support files from CIsoSurface package
- tribox.h, tribox.cpp
    - overlap collision tests from the web
    
Dependencies
- OpenGL, GLUT, GLUI (friendly static libraries can be found in spectre/Temp/nonobtuse_lib)
- OOQP (in spectre/UsefulTools)


Overview
The GUI is all implemented using GLUI and all relevant codes are residing in main.cpp. For console arguments, refer to the init() in main.cpp. Almost all the parameters can be found in the globals declared at the top of main.cpp.

Most likely you will not have to modify any of the following files: 
smfparser.h, smfparser.cpp
    - only used to parser smf files. You shouldn't need to modify this unless there are special tags in smf that you want to handle
CIsoSurface.h, CIsoSurface.cpp
    - original Marching Cubes code. For codes that deal with MC, you should modify the subclass cnonobtusemc or tilingnonobtusemc.
nonobtuse.h, nonobtuse.cpp
    - some helper functions specific for nonobtuse meshing, you shouldn't need to modify anything here.
renderer.h, renderer.cpp
    - renderer. Only modify this if you want special rendering for debugging purposes.
Vectors.h, Vectors.cpp, tribox.h, tribox.cpp, helper.h, helper.cpp
    - more helpers and other downloaded helpers.
    

Here are the relevant files to modify the initial nonobtuse mesh generation:
cnonobtusemc.h, cnonobtusemc.cpp
- GenerateSurface() is the entry point to generate initial mesh using a scalarfield. There are two overloaded version; one to take in scalarfield in memory, the other in a file.

tilingnonobtusemc.h, tilingnonobtusemc.cpp
- GenerateSurface() is the entry point to generate initial mesh using no scalarfield (the method in the thesis).
- GenerateSurface_simpleMC() is the entry point to generate initial mesh by triangulating intersected cubes using nonobtuse MC
- markIntersectedCubes() find and mark all cubes that intersect the input mesh
- triangulate_simpleMC() triangulates the intersected cubes

- NOTE: m_triTable; this variable specifies the 256 MC configuration. It should be commented out if tilingnonobtusemc is used instead

nonobtoptn.h, nonobtoptn.cpp
- optimize_afterMove(), optimize_afterMove_noPriority(), optimize_afterMove_MCA() are the entry points for optimizing the mesh using the thesis method, one without priority queue, and MCA.
- decimate(), decimate_MC_LinearSearch() are entry points for decimating the nonobtuse mesh
- getNonobtuseRegion() defines the set of linear constraints for the optimizations
- findClosestPolygon() finds the closest polygon on the input mesh to a particular vertex
- computeOptimalLocation(), computeOptimalLocation_linearSearch(), computeOptimalLocation_radiiRandomProbing() are entry points for computing the optimal location to a vertex using the solver, linear search, or radii probing.


To modify the optimization approach, you can modify/overload optimize_afterMove() to change the ordering and the call to compute optimal location. You can also change/overload computerOptimalLocation() to modify the method of computing optimal location for each vertex move. The nonobtuse constriants can be defined in getNonobtuseRegion().
