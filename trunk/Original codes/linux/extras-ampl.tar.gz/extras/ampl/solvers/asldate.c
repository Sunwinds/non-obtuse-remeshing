long ASLdate_ASL = 20010823;
