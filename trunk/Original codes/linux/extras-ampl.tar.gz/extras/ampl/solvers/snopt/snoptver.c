char xxxvers[] = "\n@(#) SNOPT 5.3, driver 19971114; IRIX 5.3\n";
