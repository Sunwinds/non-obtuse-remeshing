char npsol_version[] = "NPSOL (19980403)";
