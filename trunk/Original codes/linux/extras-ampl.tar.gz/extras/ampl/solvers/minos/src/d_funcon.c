#ifdef __cplusplus
extern "C" {
#endif
#ifdef KR_headers
 void funcon_(){}
#else
 void funcon_(void){}
#endif
#ifdef __cplusplus
	}
#endif
