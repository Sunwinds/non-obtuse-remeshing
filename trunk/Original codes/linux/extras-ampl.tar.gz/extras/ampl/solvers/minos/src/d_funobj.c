#ifdef __cplusplus
extern "C" {
#endif
#ifdef KR_headers
 void funobj_(){}
#else
 void funobj_(void){}
#endif
#ifdef __cplusplus
	}
#endif
