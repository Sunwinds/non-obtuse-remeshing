% NLOPT_LD_VAR1: Limited-memory variable-metric, rank 1 (local, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_VAR1
  val = 13;
