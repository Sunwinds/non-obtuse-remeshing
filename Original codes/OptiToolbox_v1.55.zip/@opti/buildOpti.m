function [prob,opts] = buildOpti(varargin)
%Build an OPTI object
%
%   Called By OPTI Constructor

%   Copyright (C) 2011-2012 Jonathan Currie (I2C2)

%API Change to make optiprob redundant (1/5/12)
[prob,opts] = exPrbOpts(varargin{:});

%Check and correct problem size and setup errors
[prob,opts] = checkOpti(prob,opts);


function [prob,opts] = checkOpti(prob,opts)
%Check the objective, constraints and options when building an OPTI object

warn = strcmpi(opts.warnings,'on');

%Numerical Differences Structure
numdif = struct('grad',0,'hess',0,'jac',0);

%Sizes structure
siz = struct('ndec',[],'ncon',[],'nrow',[],'nineq',[],'neq',[],'nbnds',[],'nbin',[],'nint',[],'nqc',[],'nnlineq',[],'nnleq',[],'nsos',[],'nsos1',[],'nsos2',[]);

%--Check Objective Function--%

%Check we at least have an opti problem
if(isempty(prob.f) && isempty(prob.fun))
    %see if we have lse
    if(isempty(prob.A) || isempty(prob.b))
        error('You have not supplied the objective function in a readable form - or it is empty!');
    else %equation problem
        [prob,opts] = buildSLE(prob,opts);
        prob.sizes = siz;       
        prob.sizes.ndec = size(prob.A,1);
        return;
    end
end

%Transpose f if required
if(size(prob.f,2) > 1)
    prob.f = prob.f';
end
if(~isempty(prob.x0))
    [r,c] = size(prob.x0);
    if(r > 1 && c > 1)
        error('OPTI does not currently solve matrix problems. Please use reshape() within your objective / constraints, and pass x0 as a vector to OPTI to solve these problems');
    end
    if(c > 1)
        prob.x0 = prob.x0';
    end
end

%Check correct sizes for QP
if(~isempty(prob.H) && ~isa(prob.H,'function_handle'))
    if(isempty(prob.f))
        error('When solving a QP you must supply both H and f!');
    else
        [n,m] = size(prob.H);
        p = length(prob.f);
        if(n ~= p || m ~= p)
            error('The sizes of the QP H and f matrices don''t correspond!');
        end
    end
end

%Get ndec if not NL
if(~isempty(prob.f) && ~isa(prob.f,'function_handle'))
    siz.ndec = length(prob.f);
elseif(~isempty(prob.H) && ~isa(prob.H,'function_handle'))
    siz.ndec = size(prob.H,1);
end

%Check x0 if we have ndec
if(~isempty(siz.ndec) && ~isempty(prob.x0))
    if(siz.ndec  ~= length(prob.x0))
        error('The supplied x0 is not the correct length, expected %d x 1',siz.ndec);
    end
end

%Check for NL grad
if(~isempty(prob.fun) && isempty(prob.f))
    %dont set if derivative free optimization
    if(usesDeriv([],opts))    
        if(exist('mklJac','file'))
            if(warn)
                optiwarn('opti:mkljac','OPTI will use MKLJAC (Numerical Difference Algorithm) for the Objective Gradient Function');
            end
            %Check for Data fitting problem
            if(~isempty(prob.ydata))
                prob.f = @(x) mklJac(prob.fun,x,length(prob.ydata));
            %Normal objective, single row
            else
                prob.f = @(x) mklJac(prob.fun,x,1);
            end
%             prob.f = @(x) gradest(prob.fun,x);
            numdif.grad = 1;
        else
            error('Currently you must supply a Objective Gradient function to %s',upper(opts.solver));
        end
    end
end 

%Check for NL hess (not really used for now)
if(~isempty(prob.fun) && isempty(prob.f))
    numdif.hess = 1;
end
    

%--Check Constraints--%

%Get ndec
if(isempty(siz.ndec))
    if(~isempty(prob.x0))
        siz.ndec = length(prob.x0);
    elseif(~isempty(prob.lb))
        siz.ndec = length(prob.lb);
    elseif(~isempty(prob.ub))
        siz.ndec = length(prob.ub);
    elseif(~isempty(prob.A))
        siz.ndec = size(prob.A,2);
    elseif(~isempty(prob.Aeq))
        siz.ndec = size(prob.Aeq,2);    
    elseif(~isempty(prob.int))
        siz.ndec = length(prob.int);
    elseif(~isempty(prob.nljacstr))
        siz.ndec = size(prob.nljacstr(),2);
    elseif(~isempty(prob.Hstr))
        siz.ndec = size(prob.Hstr(),2);    
    else
        siz.ndec = []; %Can't determine sizes! All NL
    end
end

%Process Integer Constraints
prob = checkInt(prob,siz.ndec);

%Determine what constraints are used
[cA,cb,cAeq,cbeq,crl,cru,clb,cub,cqc,cint,cnl,ccl,ccu,csos] = conUsed(prob);

%Check correct constraint pairs used
if(crl && (cb || cbeq))
    error('Currently you cannot supply both linear row based constraints (rl <= Ax <= ru) and linear inequality constraints (Ax <= b, Aeqx = beq)');
end
if(cb && ~cA)
    error('You must supply A and b for Inequality Constraints!')
end
if(xor(crl,cru))
    error('You must supply both rl and ru for Row Based Linear Constraints!');
end
if(crl && ~cA)
    error('You must supply A, rl and ru for Linear Constraints!')
end
if(crl && length(prob.rl) ~= length(prob.ru))
    error('Constraint vectors rl and ru are not the same size');
end
if(xor(cAeq,cbeq))
    error('You must supply Aeq and beq for Equality Constraints!');
end
if(cnl)
    if(xor(isempty(prob.cl),isempty(prob.cu)))
        error('You must supply both bounds (cl, cu) for Nonlinear Constraints!');
    end
    if(isempty(prob.cl) && isempty(prob.nlrhs))
        %If we know ndec, we can assume all constraints are <= 0, otherwise error
        if(~isempty(siz.ndec))
            if(warn)
               optiwarn('opti:nlempty','You have not supplied the right hand side (nlrhs) or bounds (cl,cu) of the Nonlinear Constraints. OPTI will assume all are <= 0.'); 
            end
            testC = prob.nlcon(zeros(siz.ndec,1)); nnl = length(testC);
            prob.nlrhs = zeros(nnl,1);
            prob.nle = -1*ones(nnl,1);
        else
            error('You must supply the Right Hand Side (nlrhs) OR constraint bounds (cl, cu) for Nonlinear Constraints! If you wish to default to all <= 0, please supply ndec.');
        end
    end
    if(~isempty(prob.cl) && ~isempty(prob.nlrhs))
        error('Currently you cannot supply both nonlinear row based constraints (cl <= nlcon(x) <= cu) and nonlinear mixed constraints (nlcon, nlrhs, nle)');
    end
end
if(~isempty(prob.sostype) && xor(isempty(prob.sosind),isempty(prob.soswt)))
    error('You must supply both the SOS indices and weights!');
end

%See if we are constrained or not
if(~cA && ~cAeq && ~clb && ~cub && ~cqc && ~cint && ~cnl && ~csos)
    prob.iscon = 0;
    checkLP(prob);
else
    prob.iscon = 1;
end

%Get Constraint Sizes
if(crl)
    eq = prob.rl == prob.ru;
    neq = sum(eq);
    nineq = sum(~isinf(prob.rl))+sum(~isinf(prob.ru))-2*neq;
else
    if(cb); nineq = length(prob.b); else nineq = 0; end
    if(cbeq); neq = length(prob.beq); else neq = 0; end
end
if(clb); nbnds = length(find(~isinf(prob.lb) > 0)); else nbnds = 0; end
if(cub); nbnds = nbnds + length(find(~isinf(prob.ub) > 0)); end
if(cint)
    nbin = length(find(prob.int.str == 'B'));
    nint = length(find(prob.int.str == 'I'));
else
    nbin = 0; nint = 0;
end
if(cnl)
    if(~isempty(prob.nlrhs))
        nnl = length(prob.nlrhs);
    else
        nnl = length(prob.cl);
    end
else 
    nnl = 0; 
end
if(cqc); nqc = length(prob.r); else nqc = 0; end
if(csos)
    nsos = length(prob.sostype);
    [r,c] = size(prob.sostype);
    if(r > c)
        t = str2num(prob.sostype); %#ok<*ST2NM>
    else
        t = str2num(prob.sostype');
    end
    nsos1 = sum(t==1);
    nsos2 = sum(t==2);
else
    nsos = 0; 
    nsos1 = 0;
    nsos2 = 0;
end

%Collect number of constraints
ncon = nineq + neq + nbnds + nqc + nbin + nint + nnl + nsos;

%Transpose as neccesary
if(cb && size(prob.b,2) > 1)
    prob.b = prob.b';
end
if(cbeq && size(prob.beq,2) > 1)
    prob.beq = prob.beq';
end
if(crl && size(prob.rl,2) > 1)
    prob.rl = prob.rl';
end
if(cru && size(prob.ru,2) > 1)
    prob.ru = prob.ru';
end
if(clb && size(prob.lb,2) > 1)
    prob.lb = prob.lb';
end
if(cub && size(prob.ub,2) > 1)
    prob.ub = prob.ub';
end
if(cnl && size(prob.nlrhs,2) > 1)
    prob.nlrhs = prob.nlrhs';
end
if(cnl && size(prob.cl,2) > 1)
    prob.cl = prob.cl';
end
if(cnl && size(prob.cu,2) > 1)
    prob.cu = prob.cu';
end

%Fill in nle if empty (assumes all <=)
if(cnl && isempty(prob.cl) && isempty(prob.nle))
    if(warn)
        optiwarn('opti:build','Nonlinear Constraint Bounds (cl, cu) and Type (nle) are Empty - Assuming all Nonlinear Constraints are nlcon(x) <= nrhs');
    end
    prob.nle = -1*ones(nnl,1);
end

%Check for NL jac
if(cnl && isempty(prob.nljac))
    %dont set if derivative free optimization
    if(usesDeriv([],opts))                 
        if(exist('mklJac','file'))
            if(warn)
                optiwarn('opti:mkljac','OPTI will use MKLJAC (Numerical Difference Algorithm) for the Constraint Jacobian Function');
                numdif.jac = 1;
            end
            prob.nljac = @(x) mklJac(prob.nlcon,x,nnl);
        else
            error('Currently you must supply a Constraint Jacobian function to %s',upper(opts.solver));
        end
    end
end        

%Check Sizes if possible
if(cA && (siz.ndec ~= size(prob.A,2)))
    error('Constraint A matrix is the wrong size! Expected %d x %d',nineq,siz.ndec);
end
if(cAeq && (siz.ndec ~= size(prob.Aeq,2)))
    error('Constraint Aeq matrix is the wrong size! Expected %d x %d',neq,siz.ndec);
end
if(clb && (siz.ndec ~= length(prob.lb)))
    error('Incorrect size of lb! Expected %d x 1',siz.ndec);
end
if(cub && (siz.ndec ~= length(prob.ub)))
    error('Incorrect size of ub! Expected %d x 1',siz.ndec);
end
if(crl)
    if(length(prob.rl) ~= size(prob.A,1))
        error('Constraint A matrix is the wrong size! Expected %d x %d',nineq+neq,siz.ndec);
    end
    if(length(prob.rl) ~= length(prob.ru))
        error('Linear constraints bounds rl and ru are not the same length!');
    end
else
    if(cA && isempty(prob.b))
        error('You must supply both A and b for inequality constraints');
    end
    if(cA && (length(prob.b) ~= size(prob.A,1)))
        error('Constraint A matrix is the wrong size! Expected %d x %d',nineq,siz.ndec);
    end
    if(cAeq && isempty(prob.beq))
        error('You must supply both Aeq and beq for inequality constraints');
    end
    if(cAeq && (length(prob.beq) ~= size(prob.Aeq,1)))
        error('Constraint Aeq matrix is the wrong size! Expected %d x %d',neq,siz.ndec);
    end
end
if(cnl && (length(prob.nlrhs) ~= length(prob.nle)))
    error('Nonlinear RHS and e vectors are not the same length!');
end
if(ccl && ccu && (length(prob.cl) ~= length(prob.cu)))
    error('Nonlinear cl and cu vectors are not the same length!');
end
if(cqc && (siz.ndec ~= length(prob.l)))
    error('Constraint l vector is the wrong size! Expected %d x 1',siz.ndec);
end
% Quadratic Constraints
if(cqc)
    if(iscell(prob.Q))
       if(iscell(prob.l) || iscell(prob.r))
           error('Only Quadratic Constraints Q may be a cell!');
       end
       [r,c] = size(prob.Q);
       [r1,c1] = size(prob.l);
       [r2,c2] = size(prob.r);
       if(r > c)
           prob.Q = prob.Q';
           [r,c] = size(prob.Q);
       end    
       if(r1 ~= c1) %not square
           if(r1 == c)
               prob.l = prob.l';
               c1 = size(prob.l,2);
           end
       end
       if(r2 > c2)
           prob.r = prob.r';
           [~,c2] = size(prob.r);
       end
       if(c ~= c1 || c ~= c2)
           error('Quadratic Constraints Q + l + r are not the same length!');
       end
       for i = 1:r
           Q = prob.Q{i};
           l = prob.l(:,i);
           r = prob.r(i);
           if((siz.ndec ~= size(Q,1)) || (siz.ndec ~= size(Q,2)))
                error('Constraint Q matrix in cell %d is the wrong size! Expected %d x %d',i,siz.ndec,siz.ndec);
           end
           if(siz.ndec ~= size(l,1))
               error('Constraint l vector in column %d is the wrong size! Expected %d x 1',i,siz.ndec);
           end
           if(~isscalar(r))
               error('Constraint r in column %d is the wrong size! Expected 1 x 1 ',i);
           end
           e = eig(Q);
           if(any(e < 0))
               error('Constraint Q matrix in cell %d is not positive semi-definite!',i);
           end
           if(all(e == 0))
               error('Constraint Q matrix in cell %d is indefinite!',i);
           end
%            if(r < 0)
%                error('Constraint r in column %d is negative!',i);
%            end
       end
    else 
        if(size(prob.l,2) > size(prob.l,1))
            prob.l = prob.l';
        end        
        if((siz.ndec ~= size(prob.Q,1)) || (siz.ndec ~= size(prob.Q,2)))
            error('Constraint Q matrix is the wrong size! Expected %d x %d',siz.ndec,siz.ndec);
        end
        if(siz.ndec ~= size(prob.l,1))
           error('Constraint l vector is the wrong size! Expected %d x 1',siz.ndec);
       end
       if(~isscalar(prob.r))
           error('Constraint r is the wrong size! Expected 1 x 1 ');
       end
       e = eig(prob.Q);
       if(any(e < 0))
           error('Constraint Q matrix is not positive semi-definite!');
       end
       if(all(e == 0))
           error('Constraint Q matrix is indefinite!');
       end
%        if(prob.r < 0)
%            error('Constraint r is negative!');
%        end
    end
end

%Special Ordered Sets
if(csos)
    %Transposes
    [r,c] = size(prob.sostype);
    if(r > c)
        prob.sostype = prob.sostype';
    end   
    %Check types are correct
    types = str2num(prob.sostype');
    if(~all((types==1)+(types==2)))
        error('Only SOS types 1 and 2 are allowed!');
    end   
    %Check lengths + datatypes
    if(nsos == 1)
       if(iscell(prob.sosind) || iscell(prob.soswt))
           error('You have specified one SOS via sostype, but supplied a cell array of indices and/or weights! Use cells only for multiple SOS.');
       end
       if(length(prob.sosind) ~= length(prob.soswt))
           error('sosind must be the same length as soswt!');
       end
       if(any(prob.sosind < 1))
           error('SOS indices must be > 0!');
       end
       %Transposes
       [r,c] = size(prob.sosind);
       if(c > r), prob.sosind = prob.sosind'; end
       [r,c] = size(prob.soswt);
       if(c > r), prob.soswt = prob.soswt'; end       
    else
        if(~iscell(prob.sosind) || ~iscell(prob.soswt))
            error('You have specified multiple SOS via sostype, but either sosind or soswt is not a cell array! Multiple SOS must be supplied as a cell array.');
        end
        if(nsos ~= length(prob.sosind))
            error('The number of sosind vectors is not equal to the number of SOS types supplied!');
        end
        if(length(prob.sosind) ~= length(prob.soswt))
            error('The number of sosind vectors is not equal to the number of soswt vectors!');
        end
        %Transpose cells
        [r,c] = size(prob.sosind);
        if(r > c), prob.sosind = prob.sosind'; end
        [r,c] = size(prob.soswt);
        if(r > c), prob.soswt = prob.soswt'; end
        %Check vectors
        for i = 1:nsos
            ind = prob.sosind{i};
            wt = prob.soswt{i};
            if(length(ind) ~= length(wt))
                error('sosind must be the same length as soswt! (SOS #%d)',i);
            end
            if(any(ind < 1))
                error('SOS indices must be > 0! (SOS #%d)',i);
            end
            [r,c] = size(ind);
            if(c > r), prob.sosind{i} = ind'; end
            [r,c] = size(wt);
            if(c > r), prob.soswt{i} = wt'; end
        end
    end    
end

%Check bounds direction
if(clb && cub)
    if(any(prob.ub < prob.lb))
        error('A lower bound is greater than its respective upper bound!');
    end
end
if(ccl && ccu)
    if(any(prob.cu < prob.cl))
        error('A nonlinear constraint lower bound is greater than its respective upper bound!');
    end
end
if(crl && cru)
    if(any(prob.ru < prob.rl))
        error('A linear constraint lower bound is greater than its respective upper bound!');
    end
end

%Check nonlinear constraints
if(cnl)
    if(~ccl && (any(prob.nle > 1) || any(prob.nle < -1)))
        error('Nonlinear constraint type (nle) must only contain -1, 0 or 1');
    end
end      
    
%Fill in Sizes Structure
siz.ncon = ncon;
siz.nineq = nineq;
siz.neq = neq;
siz.nbnds = nbnds;
siz.nbin = nbin;
siz.nint = nint;
siz.nqc = nqc;
siz.nsos = nsos;
siz.nsos1 = nsos1;
siz.nsos2 = nsos2;
if(crl)
    siz.nrow = nineq+neq;
else
    siz.nrow = 0;
end
if(cnl)
    if(ccl)
        eq = prob.cl == prob.cu; neq = ~eq;
        ile = isfinite(prob.cu) & neq;
        ige = isfinite(prob.cl) & neq;
        siz.nnlineq = sum(ile + ige);
        siz.nnleq = sum(eq);
        %If we have dual bounds, our number of con will be out
        if(any(ile & ige))
            siz.ncon = siz.ncon + sum(ile & ige);
        end
    else
        siz.nnlineq = sum(prob.nle ~= 0);
        siz.nnleq = sum(prob.nle == 0);
    end
else
    siz.nnlineq = 0;
    siz.nnleq = 0;
end
prob.sizes = siz;
%Fill in numerical differences structure
prob.numdif = numdif;


%-- Determine Problem Type --%
%Pre Check
if(isempty(prob.H) && isempty(prob.fun))
    prb = 'LP';
elseif(isempty(prob.fun))
    prb = 'QP';
else
    prb = 'NLP';
end
%Check we don't have function handles for H, f
if(~strcmpi(prb,'NLP'))
    if(isa(prob.H,'function_handle')) %QP
        error('When solving a Quadratic Problem the H matrix must be a double matrix - not a function handle');
    end
    if(isa(prob.f,'function_handle')) %LP or %QP
        error('When solving a Linear or Quadratic Problem the f vector must be a double vector - not a function handle');
    end
end
%Check quadratic constraints
if(nqc)
    if(~strcmpi(prb,'QP'))
        error('Currently Quadratic Constraints are only supported with Quadratic Programs. Please reformulate your problem as a general nonlinear problem with nonlinear constraints');
    end
    prb = ['QC' prb];
end
%Check integer variables
if(any(prob.int.ind ~= 0) || nsos)
    if(all(prob.int.ind < 0) && strcmpi(prb,'LP')) %only allow BILPs
        prb = ['BI' prb];
    else
        prb = ['MI' prb];
    end
end
%Check if NLS
if(strcmpi(prb,'NLP') && (~isempty(prob.xdata) || ~isempty(prob.ydata)))
    prb = 'NLS';
elseif(~isempty(prob.xdata) || ~isempty(prob.ydata))
    error('Currently only Nonlinear Least Squares Problems are Supported');
end

%Check we don't have nlcon with lp/qp/other
if(cnl && isempty(strfind(prb,'NLP')))
    error('Nonlinear Constraints are only supported with Nonlinear Programs. Please reformulate your problem as a general nonlinear problem with nonlinear constraints');
end
%Check if UNO (scalar) or SNLE (vector)
if(strcmpi(prb,'NLP') && ~prob.iscon)
    % Get x0 (or try and make one)
    if(isfield(prob,'x0') && ~isempty(prob.x0))
        x0 = prob.x0;
    elseif(prob.sizes.ndec)
        x0 = zeros(prob.sizes.ndec,1);
    else
        error('OPTI cannot determine whether you are solving a UNO or SNLE. Please supply ndec or x0 to optiprob to continue.');
    end
    l = length(prob.fun(x0));
    if(l > 1)
        %Check n = n
        if(l ~= length(x0))
            error('OPTI can only solve nonlinear equations which have n equations and n variables');
        end
        prb = 'SNLE';
        %Correct for numdiff size (defaults to scalar objective)
        if(numdif.grad)
            prob.f = @(x) mklJac(prob.fun,x,l);
        end
    else    
        prb = 'UNO';
    end
end

%Matlab MI check
if(strcmpi(opts.solver,'matlab'))
    if(any(strcmpi(prb,{'MILP','MIQP','MIQCQP','MINLP'})))
        solver = checkSolver(['best_' prb]);
        if(warn)
            optiwarn('opti:mi','MATLAB does not currently supply a Mixed Integer Solver\nUsing the best solver available instead: %s.',solver);
        end
        opts = optiset(opts,'solver',solver);
    end
end

%If user has specified a problem type manually, compare to auto one
if(isfield(prob,'probtype') && ~isempty(prob.probtype))
    if(~strcmpi(prob.probtype,prb))
        %Check user field exists
        ptypes = checkSolver('ptypes');
        switch(lower(prob.probtype))
            case ptypes
                optiwarn('opti:ptype','You have specified the problem type as a %s but OPTI identified the problem type as a %s. OPTI''s decision will be overridden.',upper(prob.probtype),upper(prb));
            otherwise
                error('Unknown problem type specified in optiprob: %s',upper(prob.probtype));
        end        
    end
    prb = upper(prob.probtype);
end

%Save problem type
prob.type = prb;
if(strcmp(prob.Name,'OPTI Problem'))
    prob.Name = ['OPTI ' upper(prb) ' Problem'];
end

%-- Check (and Correct) Options based on Problem Type & Settings --%

%BILP with bounds
switch(prb)
    case 'BILP'
        if((~isempty(prob.lb) || ~isempty(prob.ub)) && warn)            
            optiwarn('opti:bilp','Bounds are not currently used in BILP problems');
        end
end

%LPSOLVE instead of LP_SOLVE
if(strcmpi(opts.solver,'lpsolve'))
    opts.solver = 'lp_solve';
end

%Check for lmder variants
if(any(strcmpi(opts.solver,{'lm_der','lm_dif','lmdif'})))
    opts.solver = 'lmder';
end

%CBC for LPs
if(strcmpi(prb,'LP') && strcmpi(opts.solver,'cbc'))
    opts.solver = 'clp';
    if(warn)
        optiwarn('opti:lp_cbc','CBC is for solving MILPs, using CLP instead.');
    end
end
if(strcmpi(prb,'QP') && strcmpi(opts.solver,'cbc'))
    opts.solver = 'clp';
    if(warn)
        optiwarn('opti:qp_cbc','CBC is for solving MIQPs, using CLP instead.');
    end
end

%Check constraints on bounded solvers
if((siz.nineq + siz.neq + siz.nnleq + siz.nnlineq) > 0)
    if(strcmpi(opts.solver,'lbfgsb'))        
        if(warn)
            optiwarn('opti:bounded','L-BFGS-B can only solve bounded problems - using IPOPT instead.')
        end
        opts.solver = 'ipopt';
    end
end
if((siz.nnleq + siz.nnlineq) > 0)
    if(strcmpi(opts.solver,'pswarm'))        
        if(warn)
            optiwarn('opti:bounded','PSwarm can only solve linearly constrained problems - using IPOPT instead.')
        end
        opts.solver = 'ipopt';
    end
end
if(((siz.neq + siz.nnleq) > 0) && ((siz.nint + siz.nbin) > 0)) %MI with Equalities
    if(strcmpi(opts.solver,'gmatlab'))
        error('The MATLAB Global Optimization GA Algorithm with Integer Constraints cannot solve Equality Constrained Problems - Please use another solver.');
    end
end

%Check data fitting problems
if(~isempty(prob.ydata))
    if((siz.nineq + siz.neq) > 0)
        if(strcmpi(opts.solver,'matlab'))        
            if(warn)
                optiwarn('opti:nls_lin','MATLAB''s LSQCURVEFIT can only solve bounded problems - using LEVMAR instead.')
            end
            opts.solver = 'levmar';
        end
    end
    if(siz.ncon > 0)
        if(strcmpi(opts.solver,'lmder'))
            if(warn)
                optiwarn('opti:nls_con','MINPACK''s LM_DER can only solve unconstrained problems - using LEVMAR instead.')
            end
            opts.solver = 'levmar';
        end
    end
    if(size(prob.ydata,2) > size(prob.ydata,1))
        prob.ydata = prob.ydata';
    end
    if(~isempty(prob.xdata) && size(prob.xdata,2) > size(prob.xdata,1))
        prob.xdata = prob.xdata';
    end
end

%Bonmin for NLPs
if((strcmpi(prb,'UNO') || strcmpi(prb,'NLP')) && strcmpi(opts.solver,'bonmin'))
    opts.solver = 'ipopt';
    if(warn)
        optiwarn('opti:nlp_bonmin','BONMIN is for solving MINLPs, using IPOPT instead.');
    end
end

%Unconstrained QP (-H\f)
if(strcmpi(prb,'QP') && ~prob.iscon)
    opts.solver = 'matlab';
    if(warn)
        optiwarn('opti:uQP','You have supplied an Unconstrained QP. This will be solved using -H\\f.');
    end
end

%AUTO solver - replace with best for problem type
if(strcmpi(opts.solver,'auto'))
    try
        opts.solver = lower(checkSolver(['best_' prb]));
    catch ME
        %Convert QCQP problems to general nonlinear (for now)
        if(any(strcmpi(prb,{'QCQP','MIQP','MIQCQP'})))
            if(warn)
                optiwarn('opti:qcqp','OPTI cannot find a solver to solve a %s explicitly. It will converted to a (MI)NLP to be solved.',upper(prb));
            end
            %Do conversion then return (internally calls this function)
            [prob,opts] = QCQP2NLP(prob,opts);
            return;
        else
            rethrow(ME);
        end
    end
end

%Some won't solve without linear constraints
if(any(strcmpi(prb,{'LP','QP'})))
    if(any(strcmpi(opts.solver,{'CPLEX'})) && (prob.sizes.nineq < 1) && (prob.sizes.neq < 1))
        oS = opts.solver;
        checkSolver('clp');
        opts.solver = 'clp';
        if(warn)
            optiwarn('opti:missA','%s does not support problems without Linear Constraints. Using %s instead',upper(oS),upper(opts.solver));
        end
    end    
end

%Only certain solvers solve SOS problems
if(csos && ~any(strcmpi(opts.solver,{'CPLEX','LP_SOLVE','CBC'})))
    oS = opts.solver;
    if(checkSolver('cplex',0)) %prefer cplex, but may not be available
        opts.solver = 'cplex';
    elseif(checkSolver('lp_solve',0))
        opts.solver = 'lp_solve';
    else
        error('You do not have a solver which can solve problems specified with SOS');
    end
    if(warn)
        optiwarn('opti:consos','%s does not solve MILPs with Special Ordered Sets. Using %s instead.',upper(oS),upper(opts.solver));
    end
end
        
%Check constrained NLS
if(strcmpi(prb,'NLS') && ncon)
    if(~any(strcmpi(opts.solver,{'mkltrnls','levmar','matlab'})))
        oS = opts.solver;
        if((neq+nineq) > 0) %only levmar solves linearly constrained NLS
            checkSolver('levmar');
            opts.solver = 'levmar';
        else
            checkSolver('mkltrnls');
            opts.solver = 'mkltrnls';
        end
        if(warn)
            optiwarn('opti:connls','%s does not solve constrained Nonlinear Least Squares Problems. Using %s instead.',upper(oS),upper(opts.solver));
        end
    end
end

%Check for solver options specified for the wrong solver
if(~isempty(opts.solverOpts) && isfield(opts.solverOpts,'req_solver'))
    if(~strcmp(opts.solverOpts.req_solver,opts.solver))
        optiwarn('opti:reqslv','The solver being used is %s, but the specified solver options are for %s. OPTI will ignore these options.',upper(opts.solver),upper(opts.solverOpts.req_solver));
        opts.solverOpts = [];
    end
end

%Check xdata supplied for fun(x,xdata) problems
if(strcmpi(prb,'NLS') && nargin(prob.fun) > 1 && isempty(prob.xdata))
    error('The supplied objective function requires more than 1 input, but xdata is empty! OPTI assumes fun(x,xdata) based on this configuration.');
end

%Binary constraints for OPTI, BONMIN, GMATLAB - use bounds
if(any(strcmpi(opts.solver,{'opti','bonmin','gmatlab'})) && any(prob.int.ind < 0))
    %lower bounds
    if(isempty(prob.lb))
        prob.lb = -Inf(siz.ndec,1);
        prob.lb(prob.int.ind < 0) = 0;
    else
        prob.lb(prob.int.ind < 0) = 0;
    end
    %upper bounds
    if(isempty(prob.ub))
        prob.ub = Inf(siz.ndec,1);
        prob.ub(prob.int.ind < 0) = 1;
    else
        prob.ub(prob.int.ind < 0) = 1;
    end
end

%Check # Hessian Multiplier Args (needs to be three)
if(~isempty(prob.Hmul))
    if(nargin(prob.Hmul) < 3)
        error('A Hessian-times-vector product function (Hmul) requires 3 inputs - Hmul(x,lambda,v)');
    end
end
    
%Check sense, add minus if maximization
if(prob.sense < 0)
    switch(prb)
        case {'LP','MILP','BILP'}
            prob.f = -prob.f;
        case 'QP'
            prob.H = -prob.H;
            prob.f = -prob.f;
        case {'UNO','NLS','NLP','MINLP'}
            prob.fun = @(x) -prob.fun(x);
            if(~isempty(prob.f))
                prob.f = @(x) -prob.f(x);
            end
            %Hessian?
    end
end



function c = checkInt(c,ndec)
%Check and assign the Integer Constraints

% if(isempty(ndec))
%     error('Cannot determine number of decision variables to process integer constraints');
% end

if(isempty(c.int))
    c.int = struct('str',char('C'*ones(1,ndec)),'ind',zeros(1,ndec),'idx',[]);
    return;
end

if(~ischar(c.int) && ~isnumeric(c.int))
    error('The integer variable string must be a char array or double vector!');
end

if(ischar(c.int) && (length(c.int) ~= ndec))
    error('Integer Variable String is not the correct length! Expected 1 x %d',ndec);
end
if(isnumeric(c.int) && (length(c.int) > ndec))
    error('Integer Variable Index Vector is not the correct length! Expected MAX 1 x %d',ndec);
end

str = ones(1,ndec);
ind = zeros(1,ndec);

if(ischar(c.int))
    idx = []; j = 1;
    for i = 1:ndec
        switch(lower(c.int(i)))
            case 'c'
                str(i) = 'C';
                ind(i) = 0;
            case 'b'
                str(i) = 'B';
                ind(i) = -1;
            case 'i'
                str(i) = 'I';
                ind(i) = 1;
                idx(j) = i; j = j + 1; %#ok<AGROW>
            otherwise
                error('Unknown character %s in Integer Variable String!',c.int(i));
        end
    end
else
    if(any(c.int == 0))
        error('Indicies of integer variables must be >= 1')
    end
    if(any(c.int > ndec))
        error('An integer index is > ndec!');
    end
    str = char('C' * str); str(c.int) = 'I';
    ind(c.int) = 1;
    idx = c.int;
end

c.int = struct('str',char(str),'ind',ind,'idx',idx);


function [cA,cb,cAeq,cbeq,cru,crl,clb,cub,cqc,cint,cnl,ccl,ccu,csos] = conUsed(c)
%Determine what constraints are not empty

if(isempty(c.A)); cA = 0; else cA = 1; end
if(isempty(c.b)); cb = 0; else cb = 1; end
if(isempty(c.Aeq)); cAeq = 0; else cAeq = 1; end
if(isempty(c.beq)); cbeq = 0; else cbeq = 1; end
if(isempty(c.ru)); cru = 0; else cru= 1; end
if(isempty(c.rl)); crl = 0; else crl = 1; end
if(isempty(c.lb)); clb = 0; else clb = 1; end
if(isempty(c.ub)); cub = 0; else cub = 1; end
if(isempty(c.Q)); cqc = 0; else cqc = 1; end
if(any(c.int.str ~= 'C')); cint = 1; else cint = 0; end
if(isempty(c.nlcon)); cnl = 0; else cnl = 1; end
if(isempty(c.cl)); ccl = 0; else ccl = 1; end
if(isempty(c.cu)); ccu = 0; else ccu = 1; end
if(isempty(c.sosind)); csos = 0; else csos = 1; end


function checkLP(prob)
%Check if we are solving an unconstrained LP
if(isempty(prob.H) && isempty(prob.fun) && ~prob.iscon)
    error('When solving an LP the problem must be constrained!');
end


function [prob,opts] = buildSLE(prob,opts)
%Build Problem for System of Linear Equations

prob.type = 'SLE';

%Check we have A + b + correct sizes
if(isempty(prob.A) || isempty(prob.b))
    error('You must supply both A + b to solve a SLE');
end
if(size(prob.A,1) ~= length(prob.b))
    error('Equation RHS vector b is the wrong size! Expected %d x 1',size(prob.A,1));
end

%AUTO solver - replace with best for problem type
if(strcmpi(opts.solver,'auto'))
    opts.solver = lower(checkSolver(['best_' prob.type]));
end

%MLDIVIDE solver
if(strcmpi(opts.solver,'mldivide'))
    opts.solver = 'matlab';
end

%no constraints
prob.iscon = 0; 



function [prob,opts] = exPrbOpts(varargin)
%Extract the problem and options from the supplied arguments to opti

switch(nargin)
    case 0
        optiprob;
        error('You cannot create an empty OPTI object');
    case 1 %opti(prob) or opti(optiObj)
        if(isempty(varargin{1}))
            error('You cannot create an empty OPTI object');
        elseif(isstruct(varargin{1}))
            prob = optiprob(varargin{1});
            opts = optiset(); %default opts
        elseif(isa(varargin{1},'opti'))
            error('opti(optiObj) is not implemented');
        elseif(ischar(varargin{1}))
            error('Unknown constructor calling form with argument ''%s''',varargin{1});
        else
            error('Unknown calling form for OPTI!');
        end
    case 2 %opti(prob,opts) OR opti('field',value) OR opti(optiObj,opts)
        if(isstruct(varargin{1}) && isstruct(varargin{2}))
            prob = optiprob(varargin{1});
            opts = optiset(varargin{2});
        elseif(ischar(varargin{1}))
            prob = optiprob(varargin{:});
            opts = optiset();
        elseif(isa(varargin{1},'opti'))
            if(isstruct(varargin{2}) && isfield(varargin{2},'solver'))
                prob = getProb(varargin{1});
                opts = optiset(varargin{2});
            else
                error('opti(optiObj,arg) is not implemented unless arg is an options structure');
            end
        else
            error('Unknown calling form for OPTI!');
        end
        
    otherwise   
        if(isa(varargin{1},'opti'))
            oprob = getProb(varargin{1});
        else
            oprob = [];
        end
        
        try
            if(~isempty(oprob))
                prob = optiprob(oprob,varargin{2:end});
            else
                prob = optiprob(varargin{:});
            end
        catch ME
            throwAsCaller(ME);
        end
        if(~isempty(prob.opts))
            opts = prob.opts;
        else
            opts = optiset(); %default
        end
end
if(isfield(prob,'opts'))
    prob = rmfield(prob,'opts'); %don't keep a copy
end

