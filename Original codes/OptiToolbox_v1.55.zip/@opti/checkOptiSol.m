function [ok,msg] = checkOptiSol(optObj)
%CHECKOPTISOL  Check the solution to an optimization for errors
%
%   Called by OPTI / checkSol

%   Copyright (C) 2011 Jonathan Currie (I2C2)

ok = 1; msg = 'Solution Appears OK';

lintol = 1e-6;
quadtol = 1e-6;
nllintol = 1e-6;
inttol = 1e-5;

%Check Exit Flag
if(optObj.ef < 1)
    ok = 0;
    switch(optObj.ef)
        case 0
            msg = 'Iterations Exceeded';
        case -1
            msg = 'Infeasible';
        otherwise
            msg = 'Solver Error';
    end
    return;
end

%Check Linear Constraints
prob = optObj.prob; 
x = optObj.sol; [r,c] = size(x);
if(c > r), x = x'; end
if(~isempty(prob.rl))
    %Check Row Bounds
    if(~isempty(prob.A))
        ole = isinf(prob.rl); oge = isinf(prob.ru);
        eq = ~(prob.ru-prob.rl); bth = ~(ole+oge+eq);
        le = logical(ole+bth); ge = logical(oge+bth); 
        if(any(le))
            res = (prob.A(le,:) * x - prob.ru(le)) > lintol;
            if(any(res))               
                ok = 0;
                msg = sprintf('%d Upper Linear Inequality Constraint(s) Broken',sum(res));
                return;
            end
        end
        if(any(ge))
            res = (prob.rl(ge) - prob.A(ge,:) * x) > lintol;
            if(any(res))
                ok = 0;
                msg = sprintf('%d Lower Linear Inequality Constraint(s) Broken',sum(res));
                return;
            end
        end
        if(any(eq))
            res = abs(prob.A(eq,:) * x - prob.rl(eq))  > lintol;
            if(any(res))
                ok = 0;
                msg = sprintf('%d Linear Equality Constraint(s) Broken',sum(res));
                return;
            end
        end
    end
else
    %Check Inequality
    if(~isempty(prob.A))
        res = (prob.A * x - prob.b) > lintol;
        if(any(res))
            ok = 0;
            msg = sprintf('%d Linear Inequality Constraint(s) Broken',sum(res));
            return;
        end
    end
    %Check Equality
    if(~isempty(prob.Aeq))
        res = abs(prob.Aeq * x - prob.beq)  > lintol;
        if(any(res))
            ok = 0;
            msg = sprintf('%d Linear Equality Constraint(s) Broken',sum(res));
            return;
        end
    end
end
%Check Bounds
if(~isempty(prob.lb))
    res = x < (prob.lb-lintol);
    if(any(res))
        ok = 0;
        msg = sprintf('%d Lower Bound(s) Broken',sum(res));
        return;
    end
end
if(~isempty(prob.ub))
    res = x > (prob.ub+lintol);
    if(any(res))
        ok = 0;
        msg = sprintf('%d Upper Bounds Broken',sum(res));
        return;
    end
end

%Check Quadratic Constraints
if(~isempty(prob.Q))
    if(iscell(prob.Q)) %multiple    
        len = size(prob.Q,2);
        for i = 1:len
           qc = x'*prob.Q{i}*x + prob.l(:,i)'*x - prob.r(i);   
            if(any(qc > quadtol))
                ok = 0;
                msg = sprintf('Quadratic Inequality Constraint %d Broken',i);
                return;
            end             
        end        
    else %single
        qc = x'*prob.Q*x + prob.l'*x - prob.r;        
        if(any(qc > quadtol))
            ok = 0;
            msg = 'Quadratic Inequality Constraint Broken';
            return;
        end
    end
end       

%Check Integer Constraints
if(any(prob.int.str == 'I'))
    res = abs(x(prob.int.idx) - round(x(prob.int.idx))) > inttol;
    if(any(res))
        ok = 0;
        msg = sprintf('%d Integer Constraint(s) Broken',sum(res));
        return;
    end
end
%Check Binary Constraints
if(any(prob.int.str == 'B'))
    idx = find(prob.int.str == 'B');
    if(any(abs(x(idx) - round(x(idx))) > inttol) || any(x(idx) > (1+lintol)) || any(x(idx) < 0-lintol))
        ok = 0;
        msg = 'Binary Constraint Broken';
        return;
    end
end

%Check Nonlinear Constraints
if(~isempty(prob.nlcon))
    sol = prob.nlcon(x);
    %Check Row Bounds
    if(~isempty(prob.cl))
        %Indices
        eq = prob.cl == prob.cu; neq = ~eq;
        ile = isfinite(prob.cu) & neq;
        ige = isfinite(prob.cl) & neq;
        if(any(ile))
            if(any(sol(ile) - prob.cu(ile) > nllintol))
                ok = 0;
                msg = 'Nonlinear <= Inequality Constraints Broken';
                return;
            end
        end
        if(any(ige))
            if(any(prob.cl(ige) - sol(ige) > nllintol))
                ok = 0;
                msg = 'Nonlinear >= Inequality Constraints Broken';
                return;
            end
        end
        if(any(eq))
            if(any(abs(sol(eq) - prob.cl(eq)) > nllintol))
                ok = 0;
                msg = 'Nonlinear Equality Constraints Broken';
                return;
            end
        end
    else        
        max_in = find(prob.nle == 1);
        min_in = find(prob.nle == -1);
        eq = find(prob.nle == 0);
        if(max_in)
            if(any(prob.nlrhs(max_in) - sol(max_in) > nllintol))
                ok = 0;
                msg = 'Nonlinear >= Inequality Constraints Broken';
                return;
            end
        end
        if(min_in)
            if(any(sol(min_in) - prob.nlrhs(min_in) > nllintol))
            ok = 0;
                msg = 'Nonlinear <= Inequality Constraints Broken';
                return;
            end
        end
        if(eq)
            if(any(abs(sol(eq) - prob.nlrhs(eq)) > nllintol))
                ok = 0;
                msg = 'Nonlinear Equality Constraints Broken';
                return;
            end
        end
    end
end    