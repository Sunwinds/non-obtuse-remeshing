%% IPOPT Install for OPTI Toolbox
% Supplied binaries are built from Ipopt v3.10.2, MUMPS v4.10.0, METIS v4.0.3 and MKL 10.3.

%   Copyright (C) 2011 Jonathan Currie (I2C2)

% This file will help you compile Interior Point OPTimizer (IPOPT) for use 
% with MATLAB. 

% My build platform:
% - Windows 7 SP1 x64
% - Visual Studio 2010
% - Intel Compiler XE (FORTRAN)
% - Intel Math Kernel Library 10.3

% Due to licensing precompiled libraries have not been supplied with this
% toolbox. However instructions below describe how to build your own from
% the source! The supplied MEX files will require the VC++ 2010 Runtime.


% To recompile you will need to get / do the following:

% 1) Get IPOPT
% IPOPT is available from http://www.coin-or.org/download/source/Ipopt/.
% Download the latest version of the source.

% 2) Compile IPOPT
% IPOPT is supplied with projects for VS 10.0 and VS 8.0 with Intel Fortran
% Compiler. However you won't need the Fortran libraries if you use the
% MUMPS solver and Intel MKL - meaning we only have to compile libIpopt.
% From Ipopt/MSVisualStudio/v8-fort open IpOpt-vc10.sln in VS 2010 and 
% complete the following steps to compile libIpopt:
%
%   a) In the solution explorer right click on IpOpt-vc10 and goto
%   Configuration Properties -> C/C++ -> General and in Additional Include
%   Directories add the MUMPS includes (see the help file 
%   opti_MUMPS_Install.m for details on getting MUMPS):
%   MUMPS_xxx\include
%   MUMPS_xxx\libseq
%   b) Under General change the Configuration Type to:
%       Static Library (.lib)
%   and Whole Program Optimization to:
%       No Whole Program Optimization
%   c) In C/C++ -> Code Generation change the Runtime Library to
%   Multi-threaded DLL (/MD). This step is needed to match the same setting
%   in the MUMPS and METIS libraries (you can't mix them).
%   d) In config.h change line 4 to:
%       #define COIN_HAS_METIS 1
%   and line 7 to:
%       #define COIN_HAS_MUMPS 1
%   and line 9 to:
%       #undef COIN_HAS_HSL
%   and line 13 to:
%       #undef HAVE_LINEARSOLVERLOADER
%   and line 16 to:
%       #undef HAVE_PARDISO
%   e) Create a new solution platform for x64 if required, ensure you are
%   building a 'Release MKL' (although 'Release should be fine'), and build 
%   the project!
%   f) Copy the generated .lib file to the following folder:
%
%   OPTI/Solvers/ipopt/Source/lib/win32 or win64
%
%   And rename it libIpopt.lib.

% Next we need to copy all the required header files (there are a few!).
% From Ipopt/src/Common copy all header files to:
%
%   OPTI/Solvers/ipopt/Source/Include/Common
%
% From Ipopt/src/Interfaces copy all header files to:
%
%   OPTI/Solvers/ipopt/Source/Include/Interfaces
%
% From Ipopt/src/LinAlg copy the following header files to:
%
%   OPTI/Solvers/ipopt/Source/Include/LinAlg
%
% All header files from IpMatrix.h to IpZeroMatrix.h.
% Also from Ipopt-xxx/BuildTools/headers copy all header files to:
%
%   OPTI/Solvers/ipopt/Source/Include/BuildTools

% One final change is required to the copied IpTypes.hpp, comment the
% following line:
%   typedef FORTRAN_INTEGER_TYPE ipfint;

% 3) Complete MUMPS Compilation
% Supplied with this toolbox is the MUMPS linear system solver and METIS
% libraries. These are required when linking IPOPT so make sure you have
% built these first! See opti_MUMPS_Install.m in Solvers/mumps for more
% information.

% 4) Get IPOPT MEX Interface
% Supplied with the IPOPT source is a MEX interface by Peter Carbonetto.
% This is in Ipopt/contrib/MatlabInterface/src. Copy all .cpp files to:
%
%   OPTI/Solvers/ipopt/Source
%
% And all .h files to:
%
%   OPTI/Solvers/ipopt/Source/Include

% 5) Compile the MEX File
% The code below will automatically include all required libraries and
% directories to build the IPOPT MEX file. Once you have completed all the
% above steps, simply run this file to compile IPOPT! You MUST BE in the 
% base directory of OPTI!

clear ipopt

% Modify below function if it cannot find Intel MKL on your system.
[MKLdir,COMPdir] = opti_FindMKL();

switch(computer)
    case 'PCWIN'
        libdir = ' -Llib\win32\';
        mumpsdir = ' -L..\..\mumps\Source\lib\win32\ ';
        MKLlibdir = [' -L"' MKLdir 'lib\ia32\" '];
        COMPlibdir = [' -L"' COMPdir 'lib\ia32\" '];
    case 'PCWIN64' 
        libdir = ' -Llib\win64\';
        mumpsdir = ' -L..\..\mumps\Source\lib\win64\ ';
        MKLlibdir = [' -L"' MKLdir 'lib\intel64\" '];
        COMPlibdir = [' -L"' COMPdir 'lib\intel64\" '];
end

fprintf('\n------------------------------------------------\n');
fprintf('IPOPT MEX FILE INSTALL\n\n');

%Get IPOPT Libraries
post = [' -IInclude -IInclude/Common -IInclude/BuildTools -IInclude/Interfaces -IInclude/LinAlg ' libdir ' -llibIpopt'];
%Get MUMPS Libraries
post = [post mumpsdir '-ldmumps_c -ldmumps_fortran -llibseq_c -llibseq_fortran -lmetis -lmumps_common_c -lpord_c'];
%Get Intel Fortran Libraries + Common MKL threaded driver
post = [post COMPlibdir '-lifconsol -llibifcoremd -llibifportmd -llibmmd -llibirc -lsvml_disp -lsvml_dispmd -llibiomp5md'];

%Get Arch Dependent MKL Libraries + Settings
switch(computer)
    case 'PCWIN'
        post = [post MKLlibdir '-lmkl_intel_c -lmkl_intel_thread -lmkl_core'];
        post = [post ' -DMUMPS_ARITH=2 -output ipopt'];
    case 'PCWIN64'
        post = [post MKLlibdir '-lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core'];
        post = [post ' -largeArrayDims -output ipopt'];            
end

%CD to Source Directory
cdir = cd;
cd 'Solvers/ipopt/Source';

%Compile & Move
pre = 'mex -v matlabexception.cpp matlabfunctionhandle.cpp matlabjournal.cpp iterate.cpp ipoptoptions.cpp options.cpp sparsematrix.cpp callbackfunctions.cpp matlabinfo.cpp matlabprogram.cpp ipopt.cpp';
try
    eval([pre post])
    movefile(['ipopt.' mexext],'../','f')
    fprintf('Done!\n');
catch ME
    cd(cdir);
    error('opti:ipopt','Error Compiling IPOPT!\n%s',ME.message);
end
cd(cdir);
fprintf('------------------------------------------------\n');