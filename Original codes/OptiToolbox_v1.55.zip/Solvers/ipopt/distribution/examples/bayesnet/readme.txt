NOTE: The Bayes Net example in this subdirectory is no longer being
maintained and should not be used.
