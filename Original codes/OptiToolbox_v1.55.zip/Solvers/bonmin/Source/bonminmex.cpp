/* BONMINMEX - A MEX Interface to BONMIN MINLP Solver
 * Copyright (C) Jonathan Currie 2011 (I2C2)
 */

/* Based heavily (if not all) on the IPOPT interface by Peter Carbonetto */

#include "mex.h"
#include "Coin_C_defines.h"
#include "config_bonmin_default.h"
#include "config_ipopt_default.h"
#include "config_cbc_default.h"

#include "iterate.hpp"
#include "options.hpp"
#include "matlabinfo.hpp"
#include "matlabexception.hpp"
#include "matlabjournal.hpp"
#include "callbackfunctions.hpp"
#include "matlabprogram.hpp"

#include "BonOsiTMINLPInterface.hpp"
#include "BonIpoptSolver.hpp"
#include "BonCbc.hpp"
#include "BonBonminSetup.hpp"
#include "BonBabSetupBase.hpp"

#include "CoinMessageHandler.hpp"

#include <exception>

using namespace std;
using namespace Ipopt;
using namespace Bonmin;

//Message Handler
class DerivedHandler : public CoinMessageHandler {
public:
	virtual int print() ;
    virtual DerivedHandler * clone() const;
};
int DerivedHandler::print()
{
	mexPrintf(messageBuffer());
	mexPrintf("\n");
    mexEvalString("drawnow;"); //flush draw buffer
	return 0;
}
DerivedHandler * DerivedHandler::clone() const
{
  return new DerivedHandler(*this);
}

//Main Function
void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
    int printLevel = 0;
    int algorithm = 0;
    
    try {
        //Header
        if(nrhs < 1) {
            if(nlhs < 1)
                mexPrintf("\nThis is BONMIN v%s MEX Interface using IPOPT v%s and CBC v%s\n",BONMIN_VERSION,IPOPT_VERSION,CBC_VERSION);
            else
                plhs[0] = mxCreateString(BONMIN_VERSION);
            return;
        }      

        // Check to see if we have the correct number of input and output arguments.
        if (nrhs != 3)
          throw MatlabException("Incorrect number of input arguments");
        if (nlhs != 2)
          throw MatlabException("Incorrect number of output arguments");

        // Get the first input which specifies the initial iterate.
        Iterate x0(mxDuplicateArray(prhs[0]));

        // Get the second input which specifies the callback functions.
        CallbackFunctions funcs(prhs[1]);

        //Setup our Message Handler
        DerivedHandler *mexprinter = NULL;
        const mxArray *ptr = mxGetField(prhs[2],0,"ipopt");
        if(ptr && mxGetField(ptr,0,"print_level")) {
            printLevel = (int)*mxGetPr(mxGetField(ptr,0,"print_level"));
            if(printLevel) {
                mexprinter = new DerivedHandler();
                mexprinter->setLogLevel(printLevel); 
            }
        }
        
        // Create a new Bonmin setup object and process the options.
        BonminSetup app(mexprinter);
        app.initializeOptionsAndJournalist();
        Options options(x0,app,prhs[2]);
        
        // Set up the BONMIN console. (Don't think we need this - can enable if anyone wants?)
//         EJournalLevel printLevel = (EJournalLevel)options.bonminOptions().printLevel();
//         SmartPtr<Journal> console = new MatlabJournal(printLevel);
//         app.journalist()->AddJournal(console); 

        // The first output argument is the value of the optimization variables obtained at the solution.
        plhs[0] = mxDuplicateArray(x0);
        Iterate x(plhs[0]);        

        // The second output argument stores other information, such as
        // the exit status, the value of the Lagrange multipliers upon
        // termination, the final state of the auxiliary data, and so on.
        MatlabInfo info(plhs[1]);

        // Check to see whether the user provided a callback function for
        // computing the Hessian. This is not needed in the special case
        // when a quasi-Newton approximation to the Hessian is being used.
        if (!options.bonminOptions().useQuasiNewton() && !funcs.hessianFuncIsAvailable())
          throw MatlabException("You must supply a callback function for computing the Hessian unless you decide to use a quasi-Newton approximation to the Hessian");

        // If the user tried to use her own scaling, report an error.
        if (options.bonminOptions().userScaling())
          throw MatlabException("The user-defined scaling option does not work in the MATLAB interface for BONMIN");
        
        // Create a new instance of the constrained, mixed integer nonlinear program.
        MatlabProgram* matlabProgram = new MatlabProgram(x0,funcs,options,x,options.getAuxData(),info);
        SmartPtr<TMINLP> program = matlabProgram;

        //Set my defaults
        app.options()->SetIntegerValue("bonmin.bb_log_level",2); //only applicable if we set the handler above
        app.options()->SetIntegerValue("bonmin.bb_log_interval",25);
        
        //Set BONMIN specific options
        if(mxGetField(prhs[2],0,"algorithm"))
            algorithm = (int)*mxGetPr(mxGetField(prhs[2],0,"algorithm"));
        switch(algorithm)
        {
            case 0:
                app.readOptionsString("bonmin.algorithm B-BB\n");
                break;
            case 1:
                app.readOptionsString("bonmin.algorithm B-OA\n");
                break;
            case 2:
                app.readOptionsString("bonmin.algorithm B-QG\n");
                break;
            case 3:
                app.readOptionsString("bonmin.algorithm B-Hyb\n");
                break;
            case 4:
                app.readOptionsString("bonmin.algorithm B-Ecp\n");
                break;
            case 5:
                app.readOptionsString("bonmin.algorithm B-iFP\n");
                break;
            default:
                throw MatlabException("Unknown Algorithm Selection! Use 0 (BB), 1 (OA), 2 (QG), 3 (Hyb), 4 (Ecp) or 5 (iFP)");
                break;
        }
        if(mxGetField(prhs[2],0,"maxnodes"))
            app.options()->SetIntegerValue("bonmin.node_limit",(int)*mxGetPr(mxGetField(prhs[2],0,"maxnodes")));
        if(mxGetField(prhs[2],0,"tolint"))
            app.options()->SetNumericValue("bonmin.integer_tolerance",*mxGetPr(mxGetField(prhs[2],0,"tolint")));
        if(mxGetField(prhs[2],0,"maxtime"))
            app.options()->SetNumericValue("bonmin.time_limit",*mxGetPr(mxGetField(prhs[2],0,"maxtime")));

        // Intialize the Bonmin Setup object and process the options.
        app.initialize(GetRawPtr(program));
        
        // Ask Bonmin to solve the problem.
        Bab bb;
        bb(app); 
        
        // Collect statistics about Bonmin run
        info.setIterationCount(bb.numNodes());
        info.setExitStatus(bb.mipStatus());

        // Free the dynamically allocated memory.
        mxDestroyArray(x0);
    } 
    catch (std::exception& error) 
    {
        mexErrMsgTxt(error.what());
    }
}               


