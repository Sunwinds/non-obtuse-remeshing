%% BONMIN Install for OPTI Toolbox
% Supplied binaries are built from v1.5.2

%   Copyright (C) 2011 Jonathan Currie (I2C2)

% This file will help you compile Basic Open-source Nonlinear Mixed INteger
% programming (BONMIN) for use with MATLAB. 

% My build platform:
% - Windows 7 SP1 x64
% - Visual Studio 2010
% - Intel Compiler XE (FORTRAN)
% - Intel Math Kernel Library 10.3

% Due to licensing precompiled libraries have not been supplied with this
% toolbox. However instructions below describe how to build your own from
% the source! The supplied MEX files will require the VC++ 2010 Runtime.


% To recompile you will need to get / do the following:

% 0) Complete Compilation as per OPTI instructions for CLP, CBC, MUMPS, and
% IPOPT, in that order.

% 1) Get BONMIN
% BONMIN is available from http://www.coin-or.org/Bonmin/. Download 
% the source. 

% 2) Compile BONMIN
% The latest distribution did not have a Visual Studio solution so I had to
% manually make one. I copied the /bonmin directory structure, and manually
% add all files, and header file locations. There a couple points to
% remember though:
%
%   a) Remove the following cpp and hpp files from the project:
%       - BonCurvatureEstimator
%       - BonCurvBranchingSolver
%   b) In IpTypes.hpp comment the line 
%       - typedef FORTRAN_INTEGER_TYPE ipfint;
%   c) In C/C++ -> Code Generation change the Runtime Library to
%   Multi-threaded DLL (/MD).
%   d) Create a new solution platform for x64 if required, ensure you are
%   building a 'Release', and build the project!
%   e) Copy the generated .lib file to the following folder:
%
%   OPTI/Solvers/bonmin/Source/lib/win32 or win64
%
%   And rename it libBonmin.lib
%
%   Note expect to see a lot of warnings regarding conversion of int to
%   bool. These can be ignored as they are performance only warnings.

% Next we need to copy all the required header files (there are a few!). I
% simply copied all header files from the following folders into an
% equivalent directory structure in OPTI:
%   - Algorithms
%   - Algorithms/OaGenerators
%   - CbcBonmin
%   - Interfaces

% 3) BONMIN MEX Interface
% The BONMIN MEX Interface is based primarily on Peter Carbonetto's MEX
% Interface to IPOPT, with a few small changes I have made to enable use 
% with BONMIN. Notable changes include changes to the options + extra class
% methods in matlabprogram.

% 4) Compile the MEX File
% The code below will automatically include all required libraries and
% directories to build the BONMIN MEX file. Once you have completed all 
% the above steps, simply run this file to compile BONMIN! You MUST BE in 
% the base directory of OPTI!

clear bonmin

% Modify below function if it cannot find Intel MKL on your system.
[MKLdir,COMPdir] = opti_FindMKL();

clpdir = '..\..\clp\Source\';
cbcdir = '..\..\cbc\Source\';
mumpsdir = '..\..\mumps\Source\';
ipoptdir = '..\..\ipopt\Source\';

switch(computer)
    case 'PCWIN'
        libdir = ' -Llib\win32\';
        cbclibdir = [' -L' cbcdir 'lib\win32'];
        clplibdir = [' -L' clpdir 'lib\win32'];
        ipoptlibdir = [' -L' ipoptdir 'lib\win32'];
        mumpslibdir = [' -L' mumpsdir 'lib\win32'];
        MKLlibdir = [' -L"' MKLdir 'lib\ia32\" '];
        COMPlibdir = [' -L"' COMPdir 'lib\ia32\" '];
    case 'PCWIN64' 
        libdir = ' -Llib\win64\';
        cbclibdir = [' -L' cbcdir 'lib\win64'];
        clplibdir = [' -L' clpdir 'lib\win64'];
        ipoptlibdir = [' -L' ipoptdir 'lib\win64'];
        mumpslibdir = [' -L' mumpsdir 'lib\win64'];
        MKLlibdir = [' -L"' MKLdir 'lib\intel64\" '];
        COMPlibdir = [' -L"' COMPdir 'lib\intel64\" '];
end

fprintf('\n------------------------------------------------\n');
fprintf('BONMIN MEX FILE INSTALL\n\n');

%Get CBC & CGL Libraries
post = [' -I' cbcdir 'Include -I' cbcdir 'Include\Osi -I' cbcdir 'Include\Cgl '];
post = [post cbclibdir ' -llibCbc -llibCgl -llibOsi -llibOsiCbc -llibOsiClp -llibut'];
%Get CLP & COINUTILS libraries
post = [post ' -I' clpdir 'Include -I' clpdir 'Include\Clp -I' clpdir 'Include\Coin'];
post = [post clplibdir ' -llibClp -llibCoinUtils'];
%Get MUMPS Libraries
post = [post mumpslibdir ' -ldmumps_c -ldmumps_fortran -llibseq_c -llibseq_fortran -lmetis -lmumps_common_c -lpord_c'];
%Get Intel Fortran Libraries + Common MKL threaded driver
post = [post COMPlibdir ' -lifconsol -llibifcoremd -llibifportmd -llibmmd -llibirc -lsvml_disp -lsvml_dispmd -llibiomp5md'];
%Get IPOPT libraries
post = [post ' -I' ipoptdir 'Include\Common -I' ipoptdir 'Include\Interfaces -I' ipoptdir 'Include\LinAlg'];
post = [post ipoptlibdir ' -llibIpopt'];
%Get BONMIN libraries
post = [post ' -IInclude -IInclude/Interfaces -IInclude/CbcBonmin -IInclude/Algorithms -IInclude/Algorithms/OaGenerators' libdir ' -llibbonmin']; 

%Output Common
post = [post ' -DCOIN_MSVS -output bonmin'];

%Set arch dependent libraries
switch(computer)
    case 'PCWIN'
        post = [post MKLlibdir '-lmkl_intel_c -lmkl_intel_thread -lmkl_core'];
        post = [post ' -DMUMPS_ARITH=2'];
    case 'PCWIN64'
        post = [post MKLlibdir '-lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core'];
        post = [post ' -largeArrayDims'];             
end

%CD to Source Directory
cdir = cd;
cd 'Solvers/bonmin/Source';

%Compile & Move
pre = 'mex -v bonminmex.cpp iterate.cpp options.cpp bonminoptions.cpp matlabinfo.cpp callbackfunctions.cpp matlabexception.cpp matlabfunctionhandle.cpp matlabprogram.cpp matlabjournal.cpp sparsematrix.cpp';
try
    eval([pre post])
    movefile(['bonmin.' mexext],'../','f')
    fprintf('Done!\n');
catch ME
    cd(cdir);
    error('opti:bonmin','Error Compiling BONMIN!\n%s',ME.message);
end
cd(cdir);
fprintf('------------------------------------------------\n');
