function [x,fval,exitflag,info] = opti_bonmin(nlprob,x0)
%OPTI_BONMIN Solve a MINLP using BONMIN
%
%   [x,fval,exitflag,info] = opti_bonmin(nlprob,x0) solvers the MI nonlinear
%   program min f(x) subject to linear and nonlinear constraints using
%   BONMIN. nlprob is supplied in nl opti format (i.e. from convert(optiObj))
%   and x0 is the initial solution guess.
%
%   THIS IS A WRAPPER FOR BONMIN
%   See supplied Eclipse Public License

%   Copyright (C) 2011 Jonathan Currie (I2C2)

t = tic;
%Check required fields
if(~isfield(nlprob,'funcs') || ~isfield(nlprob,'options'))
    error('You must use convert(optiObj) or solve(optiObj) to generate a problem structure for this function');
end
%Ensure we have a starting guess
if(~exist('x0','var') || isempty(x0))
    if(isfield(nlprob,'x0') && ~isempty(nlprob.x0))
        x0 = nlprob.x0;
    else
        error('You must supply x0 to use bonmin!');
    end
end

% Run BONMIN
[x,output] = bonmin(x0,nlprob.funcs,nlprob.options);

%Collect Results
fval = nlprob.funcs.objective(x);
info.Iterations = output.iter;
info.Time = toc(t);

switch(nlprob.options.algorithm)
    case 0
        info.Algorithm = 'BONMIN: Branch & Bound using IPOPT';
    case 1
        info.Algorithm = 'BONMIN: Outer Approximation using IPOPT';
    case 2
        info.Algorithm = 'BONMIN: Quesada & Grossman Outer Approximation using IPOPT';
    case 3
        info.Algorithm = 'BONMIN: Hybrid Outer Approximation and Branch & Cut using IPOPT';
    case 4
        info.Algorithm = 'BONMIN: Outer Approximation based on FilMINT using IPOPT';
    case 5
        info.Algorithm = 'BONMIN: Iterated Feasibility Pump using IPOPT';
end

switch(output.status)
    case {0,2}
        info.StatusString = 'Optimal';
        exitflag = 1;
    case -1 %not sure if we have this one...
        info.StatusString = 'Exceeded Iterations';
        exitflag = 0;
    case 1
        info.StatusString = 'Infeasible';
        exitflag = -1;
    case 3
        info.StatusString = 'Unbounded or Infeasible';
        exitflag = -2;
    otherwise        
        info.StatusString = 'BONMIN Error';
        exitflag = -3;
end
        
