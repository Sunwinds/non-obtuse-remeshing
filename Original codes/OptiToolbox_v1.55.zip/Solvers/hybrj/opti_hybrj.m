function [x,fval,exitflag,info] = opti_hybrj(fun,grad,x0,opts)
%OPTI_HYBRJ Solve a SNLE using HYBRJ (Powell-Hybrid MINPACK Routine)
%
%   F(x) = 0
%
%   x = opti_hybrj(fun,grad,x0) solves a SNLE where fun is a vector of
%   functions to solve. grad is an optional gradient of the nonlinear
%   equations and x0 is a starting guess.
%
%   x = opti_hybrj(fun,grad,x0,opts) uses opts to pass optiset options to 
%   the solver. 
%
%   [x,fval,exitflag,info] = opti_hybrj(...) returns the objective value at
%   the solution, together with the solver exitflag, and an information
%   structure.
%
%   THIS IS A WRAPPER FOR HYBRJ + HYBRD
%   See supplied License

%   Copyright (C) 2012 Jonathan Currie (I2C2)

if(nargin < 4), opts = optiset; end
if(nargin < 3), error('HYBRJ requires at least 3 arguments'); end

%Setup display level
opts.display = dispLevel(opts.display);

t = tic;
% Run HYBRJ
[x, fval, exitflag, iter] = hybrj(fun,grad,x0,opts);

%Collect Results
info.Iterations = iter;
info.Time = toc(t);
info.Algorithm = 'HYBRJ: MINPACK Powell Hybrid';

switch(exitflag)
    case 1
        info.StatusString = 'Optimal';
    case 0
        info.StatusString = 'Exceeded Function Evaluations';
    case -1
        info.StatusString = 'Infeasible / Could not Converge';
    case -2
        info.StatusString = 'HYBRJ Error';
    case -5
        info.StatusString = 'User Exited';
    otherwise        
        info.StatusString = 'HYBRJ Error';
end
