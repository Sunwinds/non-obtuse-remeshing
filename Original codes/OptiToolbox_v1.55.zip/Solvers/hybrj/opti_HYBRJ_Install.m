%% HYBRJ + HYBRD Install for OPTI Toolbox
% Supplied binaries are built from HYBRJ + HYBRD

%   Copyright (C) 2011 Jonathan Currie (I2C2)

% This file will help you compile MINPACK HYBRJ + HYBRJ for use with MATLAB. 

% My build platform:
% - Windows 7 SP1 x64
% - Visual Studio 2010
% - Intel Compiler XE (FORTRAN)
% - Intel Math Kernel Library 10.3

% Due to licensing precompiled libraries have not been supplied with this
% toolbox. However instructions below describe how to build your own from
% the source! The supplied MEX files will require the VC++ 2010 Runtime.


% To recompile you will need to get / do the following:

% 1) Get HYBRJ + HYBRD
% HYBRJ + HYBRD are part of MINPACK available from 
% http://www.netlib.org/minpack/. Download hybrd.f plus dependences and
% hybrj.f and unzip them all to a common directory. This way we will build
% one library with both hybrd and hybrj routines.

% 2) Compile HYBRJ + HYBRD
% The downloads contain multiple FORTRAN files which we will compile below.
% Follow the steps below to compile the library:
%   a) Create a new VS2010 Visual Fortran Static Library project.
%   b) Copy the FORTRAN files you downloaded to the project directory.
%   c) From the solution explorer right click Source Files and goto Add ->
%   Exisiting Item, and add all files.
%   d) Right click the project in the solution explorer, and click
%   properties. Navigate to Configuration Properties -> Fortran ->
%   Libraries and under Runtime Library change it to "Multithreaded DLL".
%   e) Create a new solution platform for x64 if required, ensure you are
%   building a 'Release', and build the project!
%   f) Copy the generated .lib file to the following folder:
%
%   OPTI/Solvers/hybrj/Source/lib/win32 or win64
%
%   And rename it to libhybrj.lib. 

% 3) HYBRJ MEX Interface
% The HYBRJ MEX Interface is a simple MEX interface I wrote to use HYBRJ. 
% It is very basic and definitely needs upgrading! However until I have 
% time it will suffice.

% 4) Compile the MEX File
% The code below will automatically include all required libraries and
% directories to build the HYBRJ MEX file. Once you have completed all the
% above steps, simply run this file to compile HYBRJ! You MUST BE in the 
% base directory of OPTI!

clear hybrj

% Modify below function if it cannot find Intel MKL on your system.
[MKLdir,COMPdir] = opti_FindMKL();

switch(computer)
    case 'PCWIN'
        libdir = ' -Llib\win32\';
        MKLlibdir = [' -L"' MKLdir 'lib\ia32\" '];
        COMPlibdir = [' -L"' COMPdir 'lib\ia32\" '];
    case 'PCWIN64' 
        libdir = ' -Llib\win64\';
        MKLlibdir = [' -L"' MKLdir 'lib\intel64\" '];
        COMPlibdir = [' -L"' COMPdir 'lib\intel64\" '];
end

fprintf('\n------------------------------------------------\n');
fprintf('HYBRJ + HYBRD MEX FILE INSTALL\n\n');

%Get HYBRJ + HYBRD Libraries
post = [' -IInclude ' libdir ' -llibhybrj -llibut -output hybrj'];
%Get Intel Fortran Libraries + Common MKL threaded driver
post = [post COMPlibdir '-lifconsol -llibifcoremd -llibifportmd -llibmmd -llibirc -lsvml_disp -lsvml_dispmd -llibiomp5md'];

%Get Arch Dependent MKL Libraries + Settings
switch(computer)
    case 'PCWIN'
        post = [post MKLlibdir '-lmkl_intel_c -lmkl_intel_thread -lmkl_core'];
    case 'PCWIN64'
        post = [post MKLlibdir '-lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core'];
        post = [post ' -largeArrayDims'];            
end

%CD to Source Directory
cdir = cd;
cd 'Solvers/hybrj/Source';

%Compile & Move
pre = 'mex -v hybrjmex.c';
try
    eval([pre post])
    movefile(['hybrj.' mexext],'../','f')
    fprintf('Done!\n');
catch ME
    cd(cdir);
    error('opti:lmder','Error Compiling HYBRJ / HYBRD!\n%s',ME.message);
end
cd(cdir);
fprintf('------------------------------------------------\n');