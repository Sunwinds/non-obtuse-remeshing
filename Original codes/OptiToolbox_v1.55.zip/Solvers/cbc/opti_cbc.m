function [x,fval,exitflag,info] = opti_cbc(f,A,rl,ru,lb,ub,int,sos,opts)
%OPTI_CBC Solve a MILP using CBC
%
%   min f'*x      subject to:     rl <= A*x <= ru
%    x                            lb <= x <= ub
%                                 for i = 1..n: xi in Z
%                                 for j = 1..m: xj in {0,1} 
%
%   x = opti_cbc(f,A,rl,ru,lb,ub,xint) solves a MILP where f is the 
%   objective vector, A,rl,ru are the linear constraints, lb,ub are the
%   bounds and xint is a string of integer variables ('C', 'I', 'B')
%
%   x = opti_cbc(f,...,xint,sos) sos is a structure with fields sostype, 
%   sosind, soswt for SOS.
%
%   x = opti_cbc(f,...,sos,opts) uses opts to pass optiset options to the
%   solver.
%
%   [x,fval,exitflag,info] = opti_cbc(...) returns the objective value at
%   the solution, together with the solver exitflag, and an information
%   structure.
%
%   THIS IS A WRAPPER FOR CBC USING THE MEX INTERFACE
%   See supplied Eclipse Public License

%   Copyright (C) 2012 Jonathan Currie (I2C2)

t = tic;

% Handle missing arguments
if nargin < 9, opts = optiset('warnings','off'); end 
if nargin < 8, sos = []; end
if nargin < 7, int = repmat('C',size(f)); end
if nargin < 6, ub = []; end
if nargin < 5, lb = []; end
if nargin < 4, error('You must supply at least 4 arguments to opti_cbc'); end

warn = strcmpi(opts.warnings,'on');

%Check sparsity
if(~issparse(A))
    if(warn)
        optiwarn('opti:sparse','The A matrix should be sparse, correcting: [sparse(A)]');
    end
    A = sparse(A);
end

%Setup Printing
opts.display = dispLevel(opts.display);
    
%Setup Integer Vars
if(~ischar(int) || length(int) ~= length(f))
    error('The integer string must be a char array %d x 1!',length(f));
else
    int = upper(int);
    ivars = zeros(size(f));
    ivars(strfind(int,'I')) = 1;
    ind = strfind(int,'B');
    if(~isempty(ind))
        if(isempty(lb)), lb = -Inf(size(f)); end
        if(isempty(ub)), ub = Inf(size(f)); end
        ivars(ind) = 1;
        lb(ind) = 0;
        ub(ind) = 1;
    end
end

%Setup SOS
if(isfield(sos,'sostype') && ~isempty(sos.sostype))
    [r,c] = size(sos.sostype);
    if(r > c)
        sos.sostype = str2num(sos.sostype); %#ok<*ST2NM>
    else
        sos.sostype = str2num(sos.sostype');
    end
    if(length(sos.sostype) == 1)
        sos.sosind = {sos.sosind};
        sos.soswt = {sos.soswt};
    end
end

%MEX contains error checking
[x,fval,exitflag,iter] = cbc(f, A, rl, ru, lb, ub, int32(ivars), sos, opts);

%Assign Outputs
info.Iterations = iter;
info.Time = toc(t);
info.Algorithm = 'CBC: Branch and Cut using CLP';

switch(exitflag)
    case 1
        info.StatusString = 'Integer Optimal';
    case 0
        info.StatusString = 'Exceeded Iterations';
    case -1
        info.StatusString = 'Infeasible';
    case -2
        info.StatusString = 'Unbounded or Infeasible';
    case -5
        info.StatusString = 'User Exited';
    otherwise
        info.StatusString = [];
end


function  print_level = dispLevel(lev)
%Return CLP compatible display level
switch(lower(lev))
    case'off'
        print_level = 0;
    case 'iter'
        print_level = 1;
    case 'final'
        print_level = 1;
end