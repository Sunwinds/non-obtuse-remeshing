%% CBC Install for OPTI Toolbox
% Supplied binaries are built from CBC v2.7.6, CLP v1.14.6, CGL v0.57.3 

%   Copyright (C) 2011 Jonathan Currie (I2C2)

% This file will help you compile Coin-Or Branch and Cut for use with 
% MATLAB. 

% My build platform:
% - Windows 7 SP1 x64
% - Visual Studio 2010

% Due to licensing precompiled libraries have not been supplied with this
% toolbox. However instructions below describe how to build your own from
% the source! The supplied MEX files will require the VC++ 2010 Runtime.


% To recompile you will need to get / do the following:

% 1) Get CBC
% CBC is available from https://projects.coin-or.org/Cbc. Download 
% the source.

% 2) Compile CBC
% The supplied VS solution worked fine for me. Open Cbc.sln in 
% /Cbc/MSVisualStudio/v10, and build the required libs (win32 or x64), 
% ensuring you build a release! Copy the generated .lib files to the following 
% folder:
%
%   OPTI/Solvers/cbc/Source/lib/win32 or win64
%
%   - libCbc.lib
%   - libCgl.lib
%   - libOsi.lib
%   - libOsiCbc.lib
%   - libOsiClp.lib
%
%   You will also need to copy the required header files from Cbc/src to 
%   the following folder:
%
%   OPTI/Solvers/cbc/Source/Include/
%
%   Also copy the CGL header files from Cgl/src (+ few subfolders) to the 
%   following folder:
%
%   OPTI/Solvers/cbc/Source/Include/Cgl

%   Finally copy the OSI header files from Osi/src/Osi to the
%   following folder:
%
%   OPTI/Solvers/cbc/Source/Include/Osi

% 3) CBC MEX Interface
% The CBC MEX Interface is a simple MEX interface I wrote to use CBC. It is
% very basic and definitely needs upgrading! However until I have time it
% will suffice.

% 4) Compile the MEX File
% The code below will automatically include all required libraries and
% directories to build the CBC MEX file. Once you have completed all 
% the above steps, simply run this file to compile CBC! You MUST BE in 
% the base directory of OPTI!

clear cbc

clpdir = '..\..\clp\Source\';
switch(computer)
    case 'PCWIN'
        libdir = ' -Llib\win32\';
        clplibdir = [' -L' clpdir 'lib\win32'];
    case 'PCWIN64' 
        libdir = ' -Llib\win64\';
        clplibdir = [' -L' clpdir 'lib\win64'];
end

fprintf('\n------------------------------------------------\n');
fprintf('CBC MEX FILE INSTALL\n\n');

%Get CBC Libraries
post = [' -IInclude -IInclude\Osi -IInclude\Cgl ' libdir ' -llibCbc -llibCgl -llibOsi -llibOsiCbc -llibOsiClp -llibut'];
%Get CLP libraries
post = [post ' -I' clpdir 'Include -I' clpdir 'Include\Clp -I' clpdir 'Include\Coin'];
post = [post clplibdir ' -llibClp -llibCoinUtils -DCOIN_MSVS -output cbc'];

%Set arch dependent flags
switch(computer)
    case 'PCWIN64'
        post = [post ' -largeArrayDims'];            
end

%CD to Source Directory
cdir = cd;
cd 'Solvers/cbc/Source';

%Compile & Move
pre = 'mex -v cbcmex.cpp';
try
    eval([pre post])
    movefile(['cbc.' mexext],'../','f')
    fprintf('Done!\n');
catch ME
    cd(cdir);
    error('opti:clp','Error Compiling CBC!\n%s',ME.message);
end
cd(cdir);
fprintf('------------------------------------------------\n');
