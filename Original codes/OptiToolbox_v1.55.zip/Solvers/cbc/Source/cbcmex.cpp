/* CBCMEX - A simple MEX Interface to CBC MILP Solver
 * Copyright (C) Jonathan Currie 2012 (I2C2)                  
 */

#include "mex.h"
#include "Coin_C_defines.h"
#include "config_clp_default.h"
#include "config_cbc_default.h"
#include "config_cgl_default.h"
#include "OsiClpSolverInterface.hpp"
#include "CbcModel.hpp"
#include "CoinModel.hpp"
#include "CoinMessageHandler.hpp"
#include "CbcEventHandler.hpp"
#include "CglProbing.hpp"
#include "CglFlowCover.hpp"
#include "CglMixedIntegerRounding2.hpp"
#include "CbcHeuristic.hpp"
#include "CbcHeuristicLocal.hpp"
#include "CbcSOS.hpp"

#include <exception>

using namespace std;

//Function Prototypes
void checkInputs(const mxArray *prhs[], int nrhs);
double getStatus(int stat);

//Ctrl-C Detection (Undocumented - Found in gurobi_mex.c!)
#ifdef __cplusplus
    extern "C" bool utIsInterruptPending();
    extern "C" void utSetInterruptPending(bool);
#else
    extern bool utIsInterruptPending();
    extern void utSetInterruptPending(bool);
#endif

//Message Handler
class DerivedHandler : public CoinMessageHandler {
public:
	virtual int print() ;
};
int DerivedHandler::print()
{
	mexPrintf(messageBuffer());
	mexPrintf("\n");
    mexEvalString("drawnow;"); //flush draw buffer
	return 0;
}

//Ctrl-C Event Handler
class DerivedEvent : public CbcEventHandler {
public:
     virtual CbcAction event(CbcEvent whichEvent);
     virtual CbcEventHandler * clone() const ;
};
CbcEventHandler::CbcAction DerivedEvent::event(CbcEvent whichEvent)
{
    if (utIsInterruptPending()) {
        utSetInterruptPending(false); /* clear Ctrl-C status */
        mexPrintf("\nCtrl-C Detected. Exiting CBC...\n\n");
        return stop; //terminate asap
    }
    else
        return noAction; //return ok
}
CbcEventHandler * DerivedEvent::clone() const
{
     return new DerivedEvent(*this);
}

void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
    //Input Args
    double *f, *A, *rl, *ru, *lb, *ub, *H = NULL;
    int *ivars;
    
    //Return Args
    double *x, *fval, *exitflag, *iter;
    
    //Options
    int maxnodes = 10000, printLevel = 0, debug = 0;  
    double maxtime = 1000, intTol = 1e-5;
    
    //Internal Vars
    size_t ncon, ndec;
    size_t i, j, k;
    const double *sol;
    double *llb, *lub, *lrl = NULL, *lru = NULL;
    int ii, *rowInd, no = 0;
    mwIndex startRow, stopRow;
    
    //Sparse Indicing
    mwIndex *A_ir, *A_jc;
    mwIndex *H_ir, *H_jc;
    int *rows = NULL;
    CoinBigIndex *cols = NULL;
    
    //SOS
    CbcObject ** objects;
    int no_sets;
    double *sostype, *sosind, *soswt;
    int no_entries, type, *isosind; 
    
    if(nrhs < 1) {
        if(nlhs < 1)
            mexPrintf("\nThis is CBC v%s MEX Interface using CLP v%s and CGL v%s\n",CBC_VERSION,CLP_VERSION,CGL_VERSION);
        else
            plhs[0] = mxCreateString(CBC_VERSION);
        return;
    }        
    
    //Check Inputs
    checkInputs(prhs,nrhs); 
    
    //Get pointers to Input variables
	f = mxGetPr(prhs[0]);
	A = mxGetPr(prhs[1]); 
    A_ir = mxGetIr(prhs[1]);
    A_jc = mxGetJc(prhs[1]);
    rl = mxGetPr(prhs[2]);
    ru = mxGetPr(prhs[3]);
    lb = mxGetPr(prhs[4]); 
    ub = mxGetPr(prhs[5]);
    ivars = (int*)mxGetData(prhs[6]);
    if(nrhs > 9) //optional quadratic part
        H = mxGetPr(prhs[9]);

    //Get sizes
    ndec = mxGetM(prhs[0]);
    ncon = mxGetM(prhs[1]);   
    
    //Get Options if Specified
    if(nrhs > 8) {
    	if(mxGetField(prhs[8],0,"intTol"))
            intTol = *mxGetPr(mxGetField(prhs[8],0,"intTol"));
        if(mxGetField(prhs[8],0,"maxnodes"))
            maxnodes = (int)*mxGetPr(mxGetField(prhs[8],0,"maxnodes"));
        if(mxGetField(prhs[8],0,"maxtime"))
            maxtime = (int)*mxGetPr(mxGetField(prhs[8],0,"maxtime"));
        if(mxGetField(prhs[8],0,"display"))
            printLevel = (int)*mxGetPr(mxGetField(prhs[8],0,"display"));
        if(mxGetField(prhs[8],0,"debug"))
            debug = (int)*mxGetPr(mxGetField(prhs[8],0,"debug"));
    }
    
    //Create Outputs
    plhs[0] = mxCreateDoubleMatrix(ndec,1, mxREAL);
    plhs[1] = mxCreateDoubleMatrix(1,1, mxREAL);
    plhs[2] = mxCreateDoubleMatrix(1,1, mxREAL);
    plhs[3] = mxCreateDoubleMatrix(1,1, mxREAL);
    x = mxGetPr(plhs[0]); 
    fval = mxGetPr(plhs[1]); 
    exitflag = mxGetPr(plhs[2]);    
    iter = mxGetPr(plhs[3]);
    
    try
    {
        //Objects
        CbcModel cbcmodel;
        CoinModel model;
        OsiClpSolverInterface OSImodel;
        DerivedHandler *mexprinter;     
        DerivedEvent *ctrlCEvent;
        
        //Allocate Index Vector
        rowInd = (int*)mxCalloc(ncon,sizeof(int)); //set as max no of rows
        
        //Process Bounds (must copy in as we will change them!)
        llb = (double*)mxCalloc(ndec,sizeof(double));
        lub = (double*)mxCalloc(ndec,sizeof(double));   
        //Create bounds if empty
        if(mxIsEmpty(prhs[4])) {
            for(i=0;i<ndec;i++)
                llb[i] = -COIN_DBL_MAX;
        }
        else
            memcpy(llb,lb,ndec*sizeof(double));

        if(mxIsEmpty(prhs[5])) {
            for(i=0;i<ndec;i++)
                lub[i] = COIN_DBL_MAX;
        }
        else
            memcpy(lub,ub,ndec*sizeof(double));

        //Ensure 'finite' bounds
        for(i = 0; i < ndec; i++) {
            if(mxIsInf(llb[i]))
                llb[i] = -COIN_DBL_MAX;
            if(mxIsInf(lub[i]))
                lub[i] = COIN_DBL_MAX;        
        }

        //Add Linear Constraints (Sparse!)
        if(ncon) {
            for(i = 0; i < ndec; i++) {
                startRow = A_jc[i];
                stopRow = A_jc[i+1];
                no = (int)(stopRow - startRow);
                if(no > 0) {
                    for(j = 0, k = startRow; k < stopRow; j++, k++) //build int32 row indicies
                        rowInd[j] = (int)A_ir[k];                
                }
                model.addColumn(no,rowInd,&A[startRow],llb[i],lub[i],f[i]);
            }
            //Copy and process row bounds
            lrl = (double*)mxCalloc(ncon,sizeof(double));
            lru = (double*)mxCalloc(ncon,sizeof(double)); 
            for(i = 0; i < ncon; i++) {
                if(mxIsInf(rl[i]))
                    lrl[i] = -COIN_DBL_MAX;
                else
                    lrl[i] = rl[i];
                
                if(mxIsInf(ru[i]))
                    lru[i] = COIN_DBL_MAX;
                else
                    lru[i] = ru[i];
            }
        }
        else {//just bounds
            for(ii=0;ii<ndec;ii++) {
                model.setObjective(ii,f[ii]);
                model.setColumnBounds(ii,llb[ii],lub[ii]);
            }
        }
        
        //Add Row Bounds
        for (ii = 0; ii < ncon; ii++)
        	model.setRowBounds(ii, lrl[ii], lru[ii]);
        
        //Add Integer Constraints
        for(ii = 0; ii < ndec; ii++) {
            if(ivars[ii])
                model.setInteger(ii);
        }       
        
        //Add Quadratic Objective (can't work this out - suggestions anyone??)
        if(H && !mxIsEmpty(prhs[9])) {          
//            H_ir = mxGetIr(prhs[7]);
//            H_jc = mxGetJc(prhs[7]);
//            //Convert Indicies
//            mwIndex nzH = H_jc[ndec];
//            rows = (int*)mxCalloc(nzH,sizeof(int));
//            cols = (CoinBigIndex*)mxCalloc(ndec+1,sizeof(CoinBigIndex));
//            //Assign Convert Data Type Vectors
//            for(i = 0; i <= ndec; i++)
//                cols[i] = (CoinBigIndex)H_jc[i];
//            for(i = 0; i < nzH; i++)
//                rows[i] = (int)H_ir[i];
//            Load QuadObj (don't know what to do here...)
//            clpQuad = new ClpQuadraticObjective(f, ndec, cols, rows, H);
        }
        
        //Load Problem into OSI Interface
        OSImodel.loadFromCoinModel(model);
        OSImodel.setHintParam(OsiDoReducePrint,true,OsiHintTry); //prevent clp output
        //Load into CBC
        cbcmodel = CbcModel(OSImodel);        
                
        //Load Cutting Generators + Heuristics (Following examples .. not really sure here!)
        CglProbing generator1;
        generator1.setUsingObjective(true);
        generator1.setMaxPass(1);
        generator1.setMaxPassRoot(5);
        // Number of unsatisfied variables to look at
        generator1.setMaxProbe(10);
        generator1.setMaxProbeRoot(1000);
        // How far to follow the consequences
        generator1.setMaxLook(50);
        generator1.setMaxLookRoot(500);
        // Only look at rows with fewer than this number of elements
        generator1.setMaxElements(200);
        generator1.setRowCuts(3);
        //Other Generators
        CglMixedIntegerRounding2 mixedGen;
        CglFlowCover flowGen;        
        // Add in generators
        cbcmodel.addCutGenerator(&generator1,-1,"Probing");
        cbcmodel.addCutGenerator(&flowGen,-1,"FlowCover");
        cbcmodel.addCutGenerator(&mixedGen,-1,"MixedIntegerRounding");
        //Heuristics
        CbcRounding heuristic1(cbcmodel);
        cbcmodel.addHeuristic(&heuristic1);
        CbcHeuristicLocal heuristic2(cbcmodel);
        cbcmodel.addHeuristic(&heuristic2);
        
        //Setup SOS
        if(nrhs > 7 && !mxIsEmpty(prhs[7])) {
            no_sets = (int)mxGetNumberOfElements(mxGetField(prhs[7],0,"sostype"));
            if(no_sets > 0) {
                //Collect Types
                sostype = mxGetPr(mxGetField(prhs[7],0,"sostype"));

                //Allocate Set Memory
                objects = new CbcObject * [no_sets];
                //Copy in SOS data, creating CbcSOS objects as we go
                for(i=0;i<no_sets;i++) {
                    type = (int)sostype[i];
                    no_entries = (int)mxGetNumberOfElements(mxGetCell(mxGetField(prhs[7],0,"sosind"),i));
                    //Create sosind memory and copy in
                    isosind = new int[no_entries];
                    sosind = mxGetPr(mxGetCell(mxGetField(prhs[7],0,"sosind"),i));
                    for(j=0;j<no_entries;j++)
                        isosind[j] = (int)sosind[j]-1;                
                    //Get soswt
                    soswt = mxGetPr(mxGetCell(mxGetField(prhs[7],0,"soswt"),i));
                    //Create Set object
                    objects[i] = new CbcSOS(&cbcmodel,no_entries,isosind,soswt,i,type);
                    delete isosind; //free memory as we go round, CoinSet copies internally
                }

                //Add objects to model
                cbcmodel.addObjects(no_sets,objects); 
                //Priorities??

                //Delete objects
                for(i=0;i<no_sets;i++)
                    delete objects[i];
                delete [] objects;
            }
        }
        
        //Set Options
        cbcmodel.setMaximumNodes(maxnodes);
		cbcmodel.setMaximumSeconds(maxtime);
        cbcmodel.setIntegerTolerance(intTol);
        if(printLevel) {
            mexprinter = new DerivedHandler();
            mexprinter->setLogLevel(0,printLevel);
            cbcmodel.passInMessageHandler(mexprinter);
        }
        //Add Event Handler for Ctrl+C
        ctrlCEvent = new DerivedEvent();      
        cbcmodel.passInEventHandler(ctrlCEvent); 
        
        //Solve using CBC + CLP
        cbcmodel.initialSolve();    //relaxed LP
        cbcmodel.branchAndBound();  //full solve
        
        //Assign Return Arguments
        sol = cbcmodel.getColSolution();
        
        if(sol != NULL) {
            memcpy(x,sol,ndec*sizeof(double));
            *fval = cbcmodel.getObjValue();
            *exitflag = getStatus(cbcmodel.secondaryStatus());
            *iter = cbcmodel.getNodeCount();
        }
        
        //Clean up memory
        mxFree(rowInd);
        mxFree(llb);
        mxFree(lub);
        if(lrl != NULL) mxFree(lrl); lrl = NULL;
        if(lru != NULL) mxFree(lru); lru = NULL;
        if(printLevel)
            delete mexprinter;
        if(rows) mxFree(rows);
        if(cols) mxFree(cols);
        
    }
    //Error Handling (still crashes Matlab though...)
    catch(CoinError e)
    {
        mexPrintf("Caught Coin Error: %s",e.message());
    }
    catch(exception& e)
    {
        mexPrintf("Caught CBC Error: %s",e.what());           
    }  
}               


//Check all inputs for size and type errors
void checkInputs(const mxArray *prhs[], int nrhs)
{
    size_t ndec, ncon;
    
    //Correct number of inputs
    if(nrhs < 7)
        mexErrMsgTxt("You must supply at least 7 arguments to cbc (f, A, rl, ru, lb, ub, ivars)"); 
    
    //Check we have an objective
    if(mxIsEmpty(prhs[0]))
        mexErrMsgTxt("You must supply an objective function!");
    
    //Check we have some constraints
    if(mxIsEmpty(prhs[1]) && mxIsEmpty(prhs[4]) && mxIsEmpty(prhs[5]))
        mexErrMsgTxt("You have not supplied any constraints!");
   
    //Check SOS structure
    if(nrhs > 7 && !mxIsEmpty(prhs[7])) {
        if(!mxIsStruct(prhs[7]))
            mexErrMsgTxt("The SOS argument must be a structure!");       
        if(mxGetFieldNumber(prhs[7],"sostype") < 0)
            mexErrMsgTxt("The sos structure should contain the field 'sostype'");
        if(mxGetFieldNumber(prhs[7],"sosind") < 0)
            mexErrMsgTxt("The sos structure should contain the field 'sosind'");
        if(mxGetFieldNumber(prhs[7],"soswt") < 0)
                mexErrMsgTxt("The sos structure should contain the field 'soswt'");
        
        int no_sets = (int)mxGetNumberOfElements(mxGetField(prhs[7],0,"sostype")); 
        if(no_sets > 1) {
            if(!mxIsCell(mxGetField(prhs[7],0,"sosind")) || mxIsEmpty(mxGetField(prhs[7],0,"sosind")))
                mexErrMsgTxt("sosind must be a cell array, and not empty!");
            if(!mxIsCell(mxGetField(prhs[7],0,"soswt")) || mxIsEmpty(mxGetField(prhs[7],0,"soswt")))
                mexErrMsgTxt("soswt must be a cell array, and not empty!");
            if(mxGetNumberOfElements(mxGetField(prhs[7],0,"sosind")) != no_sets)
                mexErrMsgTxt("sosind cell array is not the same length as sostype!");
            if(mxGetNumberOfElements(mxGetField(prhs[7],0,"soswt")) != no_sets)
                mexErrMsgTxt("soswt cell array is not the same length as sostype!");        
        }
    }
    
    //Check options is a structure with correct fields
    if(nrhs > 8 && !mxIsStruct(prhs[8]))
        mexErrMsgTxt("The options argument must be a structure!");
    
    //Get Sizes
    ndec = mxGetM(prhs[0]);
    ncon = mxGetM(prhs[1]);
    
    //Check Constraint Pairs
    if(ncon && mxIsEmpty(prhs[2]))
        mexErrMsgTxt("rl is empty!");
    if(ncon && mxIsEmpty(prhs[3]))
        mexErrMsgTxt("ru is empty!");
    
    //Check Sparsity (only supported in A and H)
    if(mxIsSparse(prhs[0]))
        mexErrMsgTxt("Only A is a sparse matrix");
    if(!mxIsSparse(prhs[1]))
        mexErrMsgTxt("A must be a sparse matrix");
    if(nrhs > 9 && !mxIsSparse(prhs[9]))
        mexErrMsgTxt("H must be a sparse matrix");
    
     //Check Orientation
    if(mxGetM(prhs[0]) < mxGetN(prhs[0]))
        mexErrMsgTxt("f must be a column vector");
    if(mxGetM(prhs[2]) < mxGetN(prhs[2]))
        mexErrMsgTxt("rl must be a column vector");
    if(mxGetM(prhs[3]) < mxGetN(prhs[3]))
        mexErrMsgTxt("ru must be a column vector");
    if(mxGetM(prhs[4]) < mxGetN(prhs[4]))
        mexErrMsgTxt("lb must be a column vector");
    if(mxGetM(prhs[5]) < mxGetN(prhs[5]))
        mexErrMsgTxt("ub must be a column vector");
    
    //Check Sizes
    if(ncon) {
        if(mxGetN(prhs[1]) != ndec)
            mexErrMsgTxt("A has incompatible dimensions");
        if(mxGetM(prhs[2]) != ncon)
            mexErrMsgTxt("rl has incompatible dimensions");
        if(mxGetM(prhs[3]) != ncon)
            mexErrMsgTxt("ru has incompatible dimensions");
    }
    if(!mxIsEmpty(prhs[4]) && (mxGetM(prhs[4]) != ndec))
        mexErrMsgTxt("lb has incompatible dimensions");
    if(!mxIsEmpty(prhs[5]) && (mxGetM(prhs[5]) != ndec))
        mexErrMsgTxt("ub has incompatible dimensions");    
    if(nrhs > 9 && !mxIsEmpty(prhs[9]) && ((mxGetM(prhs[9]) != ndec) || (mxGetN(prhs[9]) != ndec)))
        mexErrMsgTxt("H has incompatible dimensions");
}


//Convert exiflag to OPTI status
double getStatus(int stat)
{
    double ret = -1;

    switch(stat)
    {
        case 0: //looks optimal
            ret = 1;
            break;
        case 1: //lp relax infeasible
            ret = -1;
            break;
        case 2: //gap reached
        case 3: //max nodes
        case 4: //max time
            ret = 0;
            break;
        case 5: //user exit
            ret = -5;
            break;
        default: //inaccuracy / unbounded
            ret = -2;
            break;
    }
    return ret;
}  