function plotIntCon(prob,bin)
%PLOTINTCON Plot Integer Constraints on the current figure
%   plotIntCon(prob)

%   Copyright (C) 2011 Jonathan Currie (I2C2)

xl = round(xlim); yl = round(ylim);
hold on;

%Get Problem Components
if(~isempty(prob.rl))
    [A,b,Aeq,beq] = row2gen(prob.A,prob.rl,prob.ru);
else
    A = prob.A; b = prob.b;
    Aeq = prob.Aeq; beq = prob.beq;
end
Q = prob.Q; l = prob.l; r = prob.r;
if(isempty(prob.lb)), lb = -Inf; else lb = prob.lb; end
if(isempty(prob.ub)), ub = Inf; else ub = prob.ub; end

%Generate Grid
if(bin)
    x = 0:1; y = 0:1;
else
    x = (floor(xl(1))+1):(ceil(xl(2))-1);
    y = (floor(yl(1))+1):(ceil(yl(2))-1);
end
[X,Y] = meshgrid(x,y);

%Work out feasible integer points
idx = zeros(numel(X),1); Xv = X(:); Yv = Y(:);  
for i=1:numel(X)
    xy = [Xv(i), Yv(i)]';
    if(~isempty(prob.A))
        idx(i) = all(b >= A*xy) && all(xy >= lb) && all(xy <= ub);  
    else
        idx(i) = all(xy >= lb) && all(xy <= ub);  
    end
    if(~isempty(Aeq))
        idx(i) = idx(i) && (abs(Aeq*xy-beq) < 1e-6);
    end
    if(~isempty(Q))
        for n = 1:prob.sizes.nqc
            if(iscell(Q))
                nQ = Q{n}; nl = l(:,n); nr = r(n);
            else
                nQ = Q; nl = l; nr = r;
            end
            idx(i) = idx(i) && all(xy'*nQ*xy + nl'*xy <= nr);
        end
    end
    if(~isempty(prob.nle))
        vals = prob.nlcon(xy);
        leI = find(prob.nle == -1);
        geI = find(prob.nle == 1); 
        eqI = find(prob.nle == 0);
        nlrhs = prob.nlrhs;
        idx(i) = idx(i) && all(vals(leI) <= nlrhs(leI)) && all(vals(geI) >= nlrhs(geI)) && all(abs(vals(eqI)-nlrhs(eqI)) < 1e-6);
    end
end
%Plot points
idx = logical(idx);
plot(X(idx),Y(idx),'bo','markerface','b');
plot(X(~idx),Y(~idx),'bo');

hold off;

end

