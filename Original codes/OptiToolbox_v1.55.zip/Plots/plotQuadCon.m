function plotQuadCon(Q,l,r)
%PLOTQUADCON Plot Quadratic Constraints on the current figure
%   plotQuadCon(Q,l,r)

%   Copyright (C) 2011 Jonathan Currie (I2C2)

xl = xlim; yl = ylim;
hold on;

%Colour
dkg = [0.2 0.2 0.2];

%Plot Quadratic Inequality Constraints (Inefficient.. need to solve the quadratic)
n = 40;
[x1,x2] = meshgrid(linspace(xl(1),xl(2),n),linspace(yl(1),yl(2),n));
nox = size(x1);
noy = size(x2);
obj = zeros(nox(1),noy(2));
if(iscell(Q))
    no = length(Q);
else
    no = 1;
end
for i = 1:no
    %get vars
    if(iscell(Q))
        nQ = Q{i}; nl = l(:,i); nr = r(i);
    else
        nQ = Q; nl = l; nr = r;
    end           
    % create surface
    for n = 1:nox(1)
        for m = 1:noy(2)
            x = [x1(n,m) x2(n,m)]';
            obj(n,m) = x.'*nQ*x + nl.'*x;
        end
    end
    c = contour(x1,x2,obj,'color',dkg,'levellist',nr);
    %Plot Hatch
    if(~isempty(c))
        %Get contour vectors
        vecx = diff(c(1,2:end));
        vecy = diff(c(2,2:end));
        %Rotate hatch lines based on infeasible region
        xt = [c(1,2)+vecy(1) c(2,2)-vecx(1)]'; %check rotated -90
        fval = xt.'*nQ*xt + nl.'*xt ;   
        if(fval <= nr) %rotate 90
            hvecx = -vecy;
            hvecy = vecx;
        else %rotate -90
            hvecx = vecy;
            hvecy = -vecx;
        end
        %Normalize
        av = mean(sqrt(hvecx.^2 + hvecy.^2));
        dirs = atan2(hvecy,hvecx);    
        hvecx = av*cos(dirs);
        hvecy = av*sin(dirs);
        %Shift origin
        hvecx = c(1,2:end-1) + hvecx;
        hvecy = c(2,2:end-1) + hvecy;
        %Plot
        line([c(1,2:end-1)' hvecx']',[c(2,2:end-1)' hvecy']','Color','k')
    else
        warning('opti:plot','Cannot plot inequality constraint as contour data is empty!');
    end
end

hold off;